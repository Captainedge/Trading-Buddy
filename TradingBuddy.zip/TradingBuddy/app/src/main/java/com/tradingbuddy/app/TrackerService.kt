package com.tradingbuddy.app

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.abs
import kotlin.random.Random

class TrackerService : Service() {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "tradingbuddy_tracker"
        private const val JCHANNEL = "tradingbuddy_journal"
        private const val FIVE = 300_000L
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var usm: UsageStatsManager
    private val dens: Float get() = resources.displayMetrics.density

    private var overlay: TextView? = null
    private var overlayBg: GradientDrawable? = null
    private var popup: View? = null
    private var bubble: TextView? = null
    private var bubbleBg: GradientDrawable? = null
    private var bubbleAnim: ObjectAnimator? = null
    private var bubbleScore = -1
    private var bubblePkg: String? = null
    private var checklistView: View? = null

    private var current: String? = null
    private var sessionMs = 0L
    private var lastTick = 0L
    private var lastQuery = 0L
    private var screenOn = true
    private var idle = false
    private var nextDailyWarn = 0L
    private var nextSessWarn = 0L
    private val labels = HashMap<String, String>()

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            screenOn = i.action == Intent.ACTION_SCREEN_ON
            if (!screenOn) {
                sessionMs = 0L
                nextSessWarn = 0L
                hideOverlay()
                hideBubble()
                closeChecklist()
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val c = this@TrackerService
            val now = System.currentTimeMillis()
            if (!Store.scheduledToday(c)) {
                if (!idle) {
                    idle = true
                    current = null
                    sessionMs = 0L
                    hideOverlay()
                    hideBubble()
                    closeChecklist()
                    closePopup()
                    updateNotification("Resting today 😴 (not a scheduled day)")
                }
                lastTick = now
                handler.postDelayed(this, 30_000L)
                return
            }
            if (idle) {
                idle = false
                lastQuery = now - 60 * 60 * 1000L
                lastTick = now
                updateNotification("Timing your chosen apps")
            }
            journalReminder()
            val dt = (now - lastTick).coerceIn(0L, 5000L)
            lastTick = now
            pollForeground(now)
            val pkg = current
            if (screenOn && pkg != null && pkg in Store.tracked(c)) {
                Store.add(c, pkg, dt)
                sessionMs += dt
                val used = Store.usedToday(c, pkg)
                val limitMs = Store.dailyLimitMin(c) * 60_000L
                val sessLimit = Store.sessionLimitMin(c) * 60_000L

                // First open of the day: show this app's checklist
                if (checklistView == null && popup == null && !Store.shownToday(c, pkg) &&
                    Store.checklist(c, pkg).isNotEmpty()
                ) {
                    Store.setShown(c, pkg)
                    showChecklist(pkg)
                }
                updateBubble(pkg)

                val ratio = if (limitMs > 0) used.toFloat() / limitMs
                else sessionMs.toFloat() / (30 * 60_000L)
                val (emoji, color) = moodFor(ratio)
                showOverlay("$emoji ${label(pkg)}  ·  ${fmtClock(sessionMs)}  ·  today ${fmtLong(used)}", color)
                checkLimits(pkg, used, limitMs, sessLimit)
            } else {
                hideOverlay()
                hideBubble()
                closeChecklist()
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        screenOn = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Trading Buddy is running")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(1, buildNotification(text))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Trading Buddy timer", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(JCHANNEL, "Journal reminder", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val n = buildNotification("Timing your chosen apps")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        idle = false
        lastTick = System.currentTimeMillis()
        lastQuery = lastTick - 60 * 60 * 1000L
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun pollForeground(now: Long) {
        var latest: String? = null
        try {
            val events = usm.queryEvents(lastQuery, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) latest = e.packageName
            }
        } catch (_: Exception) { }
        lastQuery = now - 1000L
        if (latest != null && latest != current) {
            current = latest
            sessionMs = 0L
            nextDailyWarn = 0L
            nextSessWarn = 0L
        }
    }

    private fun label(pkg: String): String = labels.getOrPut(pkg) {
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }
    }

    private fun journalReminder() {
        if (LocalTime.now().hour != 23) return
        if (Store.journalNotified(this) || Store.journalEntry(this, LocalDate.now()) != null) return
        Store.setJournalNotified(this)
        val intent = Intent(this, MainActivity::class.java)
            .putExtra("tab", 3)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(
            this, 2, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, JCHANNEL)
            .setContentTitle("📓 Time to journal")
            .setContentText("How did today go? It takes 30 seconds.")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(2, n)
    }

    // ---------- checklist popup ----------

    private fun showChecklist(pkg: String) {
        if (!Settings.canDrawOverlays(this)) return
        val entries = Store.checklist(this, pkg)
        if (entries.isEmpty()) return
        closeChecklist()
        val d = dens
        val checked = HashSet(Store.checkedOn(this, LocalDate.now(), pkg))
        Store.setChecked(this, pkg, checked)
        var lastScore = Store.score(this, pkg, checked)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (20 * d).toInt(), (20 * d).toInt(), (12 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 28 * d
                setColor(0xF2202030.toInt())
            }
        }
        val title = TextView(this).apply {
            text = "📋 ${label(pkg)} checklist"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val scoreTv = TextView(this).apply {
            textSize = 26f
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, (8 * d).toInt(), 0, (4 * d).toInt())
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val hint = TextView(this).apply {
            text = "Tick what you've done. Tap the floating bubble later to add more."
            textSize = 12f
            setTextColor(0xFFAAAAAA.toInt())
            gravity = Gravity.CENTER
            setPadding(0, (6 * d).toInt(), 0, (6 * d).toInt())
        }

        fun refresh(animate: Boolean) {
            val s = Store.score(this@TrackerService, pkg, checked)
            val col = scoreColor(s)
            scoreTv.text = "$s ${scoreEmoji(s)}  ${scoreLabel(s)}"
            scoreTv.setTextColor(col)
            bar.progressTintList = ColorStateList.valueOf(col)
            if (animate) {
                ObjectAnimator.ofInt(bar, "progress", bar.progress, s).setDuration(350).start()
                scoreTv.animate().scaleX(1.25f).scaleY(1.25f).setDuration(120).withEndAction {
                    scoreTv.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }.start()
            } else {
                bar.progress = s
            }
            if (s == 100 && lastScore < 100) confetti()
            lastScore = s
            updateBubble(pkg)
        }

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        entries.forEach { item ->
            list.addView(CheckBox(this).apply {
                this.text = item
                setTextColor(Color.WHITE)
                textSize = 16f
                buttonTintList = ColorStateList.valueOf(Color.WHITE)
                isChecked = item in checked
                setOnCheckedChangeListener { _, on ->
                    if (on) checked.add(item) else checked.remove(item)
                    Store.setChecked(this@TrackerService, pkg, checked)
                    refresh(true)
                }
            })
        }
        val sv = ScrollView(this)
        sv.addView(list)

        box.addView(title)
        box.addView(scoreTv)
        box.addView(bar)
        box.addView(hint)
        val maxH = (resources.displayMetrics.heightPixels * 0.4f).toInt()
        val wantH = (entries.size * 52 * d).toInt()
        box.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, minOf(maxH, wantH)))
        box.addView(Button(this).apply {
            text = "Done ✅"
            setOnClickListener { closeChecklist() }
        })

        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            dimAmount = 0.6f
        }
        try {
            wm.addView(box, lp)
            checklistView = box
            refresh(false)
        } catch (_: Exception) { }
    }

    private fun closeChecklist() {
        checklistView?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        checklistView = null
    }

    private fun confetti() {
        if (!Settings.canDrawOverlays(this)) return
        val dm = resources.displayMetrics
        val root = FrameLayout(this)
        val emojis = listOf("🎉", "✨", "💰", "📈", "🏆", "⭐")
        repeat(26) {
            val tv = TextView(this).apply {
                text = emojis.random()
                textSize = (18 + Random.nextInt(14)).toFloat()
                translationX = Random.nextFloat() * dm.widthPixels * 0.92f
                translationY = -120f
            }
            root.addView(tv, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
            ))
            tv.animate()
                .translationY(dm.heightPixels.toFloat())
                .rotation(Random.nextInt(-360, 360).toFloat())
                .setStartDelay(Random.nextInt(0, 700).toLong())
                .setDuration(1500L + Random.nextInt(0, 1200))
                .start()
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(root, lp)
            handler.postDelayed({ try { wm.removeView(root) } catch (_: Exception) { } }, 3600L)
        } catch (_: Exception) { }
    }

    // ---------- score bubble ----------

    private fun updateBubble(pkg: String) {
        if (!Settings.canDrawOverlays(this)) return
        if (Store.checklist(this, pkg).isEmpty()) { hideBubble(); return }
        val view = bubble ?: createBubble() ?: return
        if (bubblePkg != pkg) {
            bubblePkg = pkg
            bubbleScore = -1
        }
        val score = Store.score(this, pkg)
        if (score == bubbleScore) return
        val first = bubbleScore < 0
        bubbleScore = score
        view.text = "$score\n${scoreEmoji(score)}"
        bubbleBg?.setColor(scoreColor(score))
        if (!first) {
            view.animate().rotationY(360f).setDuration(500).withEndAction { view.rotationY = 0f }.start()
        }
        pulse(view, score)
    }

    private fun pulse(v: View, score: Int) {
        bubbleAnim?.cancel()
        v.scaleX = 1f
        v.scaleY = 1f
        val amp = when {
            score >= 90 -> 1.18f
            score >= 60 -> 1.1f
            else -> 1.06f
        }
        bubbleAnim = ObjectAnimator.ofPropertyValuesHolder(
            v,
            PropertyValuesHolder.ofFloat("scaleX", 1f, amp),
            PropertyValuesHolder.ofFloat("scaleY", 1f, amp)
        ).apply {
            duration = if (score < 40) 500L else 900L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    private fun createBubble(): TextView? {
        val d = dens
        val dm = resources.displayMetrics
        val size = (60 * d).toInt()
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.GRAY)
            setStroke((3 * d).toInt(), Color.WHITE)
        }
        val tv = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            background = bg
        }
        val saved = Store.bpos(this)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = saved?.first ?: (dm.widthPixels - size - (12 * d).toInt())
            y = saved?.second ?: (200 * d).toInt()
        }
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false
        tv.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = ev.rawX; downY = ev.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = ev.rawX - downX
                    val my = ev.rawY - downY
                    if (abs(mx) > 12 * d || abs(my) > 12 * d) moved = true
                    if (moved) {
                        lp.x = (startX + mx).toInt().coerceAtLeast(0)
                        lp.y = (startY + my).toInt().coerceAtLeast(0)
                        try { wm.updateViewLayout(v, lp) } catch (_: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Store.setBpos(this@TrackerService, lp.x, lp.y)
                    else bubblePkg?.let { showChecklist(it) }
                }
            }
            true
        }
        return try {
            wm.addView(tv, lp)
            bubble = tv
            bubbleBg = bg
            tv
        } catch (_: Exception) { null }
    }

    private fun hideBubble() {
        bubbleAnim?.cancel()
        bubbleAnim = null
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        bubble = null
        bubbleBg = null
        bubbleScore = -1
        bubblePkg = null
    }

    // ---------- time limits ----------

    private fun checkLimits(pkg: String, used: Long, limitMs: Long, sessLimit: Long) {
        if (limitMs <= 0 || used < limitMs) nextDailyWarn = 0L
        if (popup != null || checklistView != null) return
        val name = label(pkg)
        if (limitMs > 0 && used >= limitMs && used >= nextDailyWarn) {
            nextDailyWarn = used + FIVE
            val msgs = listOf(
                "$name limit smashed! ${fmtLong(used)} today. Your thumbs need a vacation. 🏖️",
                "Plot twist: today's $name budget is gone. Go touch some grass. 🌱",
                "Trading Buddy here! ${fmtLong(used)} of $name today. Future you says thanks if you stop. 🙏",
                "Beep boop, $name limit reached. The charts will still be there tomorrow. 🤖"
            )
            showPopup("🚨 Limit reached!", msgs.random())
        } else if (sessLimit > 0 && sessionMs >= sessLimit && sessionMs >= nextSessWarn) {
            nextSessWarn = sessionMs + FIVE
            val msgs = listOf(
                "You've been in $name for ${fmtLong(sessionMs)} straight. Stretch break? 🧘",
                "$name has had you for ${fmtLong(sessionMs)}. Look at something far away for 20 seconds. 👀",
                "${fmtLong(sessionMs)} nonstop in $name! Drink some water, then decide. 💧"
            )
            showPopup("⏰ Scroll alarm!", msgs.random())
        }
    }

    private fun alarm() {
        try {
            @Suppress("DEPRECATION")
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) { }
        try {
            RingtoneManager.getRingtone(
                this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ).play()
        } catch (_: Exception) { }
    }

    private fun showPopup(title: String, msg: String) {
        if (!Settings.canDrawOverlays(this)) return
        alarm()
        val d = dens
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((24 * d).toInt(), (24 * d).toInt(), (24 * d).toInt(), (16 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 28 * d
                setColor(0xF2202030.toInt())
            }
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = msg
            textSize = 16f
            setTextColor(0xFFDDDDDD.toInt())
            gravity = Gravity.CENTER
            setPadding(0, (12 * d).toInt(), 0, (16 * d).toInt())
        })
        box.addView(Button(this).apply {
            text = "Take me home 🏠"
            setOnClickListener { closePopup(); goHome() }
        })
        box.addView(Button(this).apply {
            text = "5 more minutes 😅"
            setOnClickListener { closePopup() }
        })
        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            dimAmount = 0.6f
        }
        try {
            wm.addView(box, lp)
            popup = box
        } catch (_: Exception) { }
    }

    private fun closePopup() {
        popup?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        popup = null
    }

    private fun goHome() {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) { }
    }

    // ---------- timer pill ----------

    private fun showOverlay(text: String, color: Int) {
        if (!Settings.canDrawOverlays(this)) return
        val view = overlay ?: createOverlay() ?: return
        overlayBg?.setColor(color)
        view.text = text
    }

    private fun createOverlay(): TextView? {
        val d = dens
        val bg = GradientDrawable().apply {
            cornerRadius = 24 * d
            setColor(0xCC000000.toInt())
        }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            background = bg
        }
        val saved = Store.pos(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = saved?.first ?: (24 * d).toInt()
            y = saved?.second ?: (48 * d).toInt()
        }
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        tv.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = ev.rawX; downY = ev.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (startX + (ev.rawX - downX)).toInt().coerceAtLeast(0)
                    lp.y = (startY + (ev.rawY - downY)).toInt().coerceAtLeast(0)
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) { }
                }
                MotionEvent.ACTION_UP -> Store.setPos(this@TrackerService, lp.x, lp.y)
            }
            true
        }
        return try {
            wm.addView(tv, lp)
            overlay = tv
            overlayBg = bg
            tv
        } catch (_: Exception) { null }
    }

    private fun hideOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        overlay = null
        overlayBg = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) { }
        hideOverlay()
        hideBubble()
        closeChecklist()
        closePopup()
        running = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
