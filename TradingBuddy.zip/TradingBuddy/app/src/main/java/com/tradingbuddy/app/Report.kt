package com.tradingbuddy.app

import android.app.Activity
import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private var printView: WebView? = null

// Opens Android's print dialog (print, or "Save as PDF") for the month's report
fun printMonthReport(activity: Activity, ym: YearMonth) {
    val html = buildReportHtml(activity, ym)
    val web = WebView(activity)
    printView = web
    var printed = false
    web.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) {
            if (printed || view == null) return
            printed = true
            val pm = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val name = "TradingBuddy_$ym"
            pm.print(name, view.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
        }
    }
    web.loadDataWithBaseURL(null, html, "text/HTML", "UTF-8", null)
}

private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

private fun f(d: Double) = String.format(Locale.US, "%.2f", d)

private fun pieSvg(slices: List<Triple<String, Double, String>>): String {
    val total = slices.sumOf { it.second }
    if (total <= 0) return "<p class='muted'>No data yet</p>"
    val cx = 95.0
    val cy = 95.0
    val r = 91.0
    val sb = StringBuilder("<svg width='190' height='190' viewBox='0 0 190 190'>")
    val used = slices.filter { it.second > 0 }
    if (used.size == 1) {
        sb.append("<circle cx='95' cy='95' r='91' fill='${used[0].third}'/>")
    } else {
        var start = -PI / 2
        for ((_, v, col) in used) {
            val ang = 2 * PI * v / total
            val end = start + ang
            val x1 = cx + r * cos(start)
            val y1 = cy + r * sin(start)
            val x2 = cx + r * cos(end)
            val y2 = cy + r * sin(end)
            val large = if (ang > PI) 1 else 0
            sb.append("<path d='M ${f(cx)} ${f(cy)} L ${f(x1)} ${f(y1)} A ${f(r)} ${f(r)} 0 $large 1 ${f(x2)} ${f(y2)} Z' fill='$col'/>")
            start = end
        }
    }
    sb.append("</svg>")
    return sb.toString()
}

private fun legend(slices: List<Triple<String, Double, String>>): String =
    slices.joinToString("") {
        "<div class='lg'><span class='sw' style='background:${it.third}'></span>${esc(it.first)}: ${it.second.toInt()}</div>"
    }

private fun cls(v: Double) = if (v > 0) "pos" else if (v < 0) "neg" else ""

fun buildReportHtml(c: Context, ym: YearMonth): String {
    val sym = Store.currency(c)
    val tracked = Store.tracked(c)
    val st = Store.monthStats(c, ym)
    val moods = listOf("😡", "😕", "😐", "🙂", "🤩")
    val planText = listOf("Broke the plan", "Partly", "Followed the plan")
    val statusText = listOf("In progress", "Passed", "Failed", "Funded", "Blown")
    val title = ym.month.getDisplayName(TextStyle.FULL, Locale.getDefault()) + " " + ym.year
    val traded = st.wins + st.losses + st.flat
    val winRate = if (traded > 0) st.wins * 100 / traded else 0
    val avgScore = Store.avgScore(c, tracked, ym.atDay(1), ym.atEndOfMonth())
    val evals = Store.evals(c).filter {
        runCatching { YearMonth.from(LocalDate.parse(it.date)) == ym }.getOrDefault(false)
    }

    val daySlices = listOf(
        Triple("Winning days", st.wins.toDouble(), "#2E9E4F"),
        Triple("Losing days", st.losses.toDouble(), "#C62828"),
        Triple("Break-even days", st.flat.toDouble(), "#9E9E9E")
    )
    val evalSlices = listOf(
        Triple("Passed", evals.count { it.status == 1 }.toDouble(), "#2E9E4F"),
        Triple("Funded", evals.count { it.status == 3 }.toDouble(), "#FFB300"),
        Triple("Failed", evals.count { it.status == 2 }.toDouble(), "#C62828"),
        Triple("Blown", evals.count { it.status == 4 }.toDouble(), "#6D1B1B"),
        Triple("In progress", evals.count { it.status == 0 }.toDouble(), "#1E88E5")
    )

    val sb = StringBuilder()
    sb.append(
        """<!DOCTYPE html><html><head><meta charset="utf-8"><style>
        @page { margin: 14mm; }
        body { font-family: sans-serif; color: #222; font-size: 12px; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        h1 { font-size: 22px; margin: 0 0 4px; }
        h2 { font-size: 15px; margin: 18px 0 6px; border-bottom: 1px solid #ccc; padding-bottom: 3px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 4px 6px; text-align: left; vertical-align: top; }
        th { background: #f1f1f1; }
        .pos { color: #2E9E4F; font-weight: bold; }
        .neg { color: #C62828; font-weight: bold; }
        .big { font-size: 26px; font-weight: bold; }
        .muted { color: #777; }
        .row { display: flex; gap: 28px; flex-wrap: wrap; align-items: center; page-break-inside: avoid; }
        .lg { margin: 3px 0; }
        .sw { display: inline-block; width: 11px; height: 11px; border-radius: 2px; margin-right: 6px; }
        .entry { border: 1px solid #ddd; border-radius: 6px; padding: 6px 8px; margin: 6px 0; page-break-inside: avoid; }
        </style></head><body>"""
    )
    sb.append("<h1>Trading Buddy · $title</h1><div class='muted'>Monthly P&amp;L and journal report</div>")

    sb.append("<h2>Summary</h2>")
    sb.append("<div class='big ${cls(st.total)}'>${esc(fmtMoney(st.total, sym))}</div>")
    sb.append("<table><tr><th>Win days</th><th>Loss days</th><th>Break-even</th><th>Win rate</th><th>Best day</th><th>Worst day</th><th>Avg checklist score</th></tr><tr>")
    sb.append("<td>${st.wins}</td><td>${st.losses}</td><td>${st.flat}</td><td>$winRate%</td>")
    sb.append("<td>${st.best?.let { "${it.first.dayOfMonth}: ${esc(fmtMoney(it.second, sym))}" } ?: "–"}</td>")
    sb.append("<td>${st.worst?.let { "${it.first.dayOfMonth}: ${esc(fmtMoney(it.second, sym))}" } ?: "–"}</td>")
    sb.append("<td>${avgScore ?: "–"}</td></tr></table>")

    sb.append("<h2>Charts</h2><div class='row'>")
    sb.append("<div>${pieSvg(daySlices)}</div><div><b>Win / loss days</b>${legend(daySlices)}</div>")
    if (evals.isNotEmpty()) {
        sb.append("<div>${pieSvg(evalSlices)}</div><div><b>Eval results</b>${legend(evalSlices)}</div>")
    }
    sb.append("</div>")

    sb.append("<h2>Evals &amp; funded accounts</h2>")
    if (evals.isEmpty()) {
        sb.append("<p class='muted'>No evals logged this month.</p>")
    } else {
        sb.append("<table><tr><th>Name</th><th>Status</th><th>Date</th><th>Cost</th></tr>")
        evals.forEach {
            sb.append("<tr><td>${esc(it.name)}</td><td>${statusText[it.status.coerceIn(0, 4)]}</td><td>${esc(it.date)}</td><td>${if (it.cost > 0) esc(fmtPlain(it.cost, sym)) else "–"}</td></tr>")
        }
        sb.append("</table>")
        sb.append("<p>Fees paid ${esc(fmtPlain(evals.sumOf { it.cost }, sym))} · payouts ${esc(fmtPlain(evals.sumOf { it.payouts }, sym))} · net ${esc(fmtMoney(evals.sumOf { it.payouts - it.cost }, sym))}</p>")
    }

    sb.append("<h2>Daily log</h2><table><tr><th>Date</th><th>P&amp;L</th><th>Checklist score</th><th>Mood</th><th>Plan</th></tr>")
    var rows = 0
    for (day in 1..ym.lengthOfMonth()) {
        val d = ym.atDay(day)
        val p = Store.pnl(c, d)
        val sc = Store.avgScore(c, tracked, d, d)
        val j = Store.journalEntry(c, d)
        if (p == null && sc == null && j == null) continue
        rows++
        val dayName = d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())
        val pText = if (p != null) esc(fmtMoney(p, sym)) else "–"
        val pCls = if (p != null) cls(p) else ""
        val mood = if (j != null) moods[(j.mood - 1).coerceIn(0, 4)] else "–"
        val plan = if (j != null) planText[j.plan.coerceIn(0, 2)] else "–"
        sb.append("<tr><td>$dayName $day</td><td class='$pCls'>$pText</td><td>${sc ?: "–"}</td><td>$mood</td><td>$plan</td></tr>")
    }
    sb.append("</table>")
    if (rows == 0) sb.append("<p class='muted'>Nothing logged this month yet.</p>")

    sb.append("<h2>Journal</h2>")
    var entries = 0
    for (day in 1..ym.lengthOfMonth()) {
        val d = ym.atDay(day)
        val j = Store.journalEntry(c, d) ?: continue
        entries++
        val dayName = d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())
        val actedText = when (j.acted) {
            1 -> " · Acted on the feeling"
            0 -> " · Held back"
            else -> ""
        }
        val imgs = j.photos.joinToString("") { n ->
            Photos.base64(c, n, 900)?.let {
                "<br><img src='data:image/jpeg;base64,$it' style='max-width:100%;max-height:300px;margin-top:6px'/>"
            } ?: ""
        }
        val note = if (j.note.isEmpty()) "<span class='muted'>(no note)</span>" else esc(j.note).replace("\n", "<br>")
        sb.append("<div class='entry'><b>$dayName $day</b> · ${moods[(j.mood - 1).coerceIn(0, 4)]} · ${planText[j.plan.coerceIn(0, 2)]}$actedText<br>$note$imgs</div>")
    }
    if (entries == 0) sb.append("<p class='muted'>No journal entries this month.</p>")

    sb.append("<p class='muted' style='margin-top:18px'>Generated by Trading Buddy on ${LocalDate.now()}</p></body></html>")
    return sb.toString()
}
