package com.tradingbuddy.app

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.TextStyle as DayStyle
import java.util.Locale
import kotlin.math.abs

val MOOD_EMOJI = listOf("😡", "😕", "😐", "🙂", "🤩")
val PLAN_LABELS = listOf("Broke the plan ❌", "Partly 😅", "Followed the plan ✅")

fun dateShort(d: LocalDate): String =
    d.dayOfWeek.getDisplayName(DayStyle.SHORT, Locale.getDefault()) + " " + d.dayOfMonth + " " +
        d.month.getDisplayName(DayStyle.SHORT, Locale.getDefault())

// ---------------- Write / Month / Search switch ----------------
@Composable
fun JournalHost(tick: Int, tracked: Set<String>) {
    var mode by remember { mutableIntStateOf(0) }
    var editDate by remember { mutableStateOf(LocalDate.now()) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Write", "Month", "Search 🔎").forEachIndexed { i, name ->
                val click: () -> Unit = {
                    if (i == 0) editDate = LocalDate.now()
                    mode = i
                }
                if (mode == i) Button(
                    onClick = click,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text(name, maxLines = 1) }
                else OutlinedButton(
                    onClick = click,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text(name, maxLines = 1) }
            }
        }
        Box(Modifier.weight(1f)) {
            val edit: (LocalDate) -> Unit = { d ->
                editDate = d
                mode = 0
            }
            when (mode) {
                0 -> key(editDate) {
                    JournalTab(tick, tracked, editDate, edit) { editDate = LocalDate.now() }
                }
                1 -> JournalMonthTab(tick, edit)
                else -> SearchTab(tick, edit)
            }
        }
    }
}

// ---------------- Expandable entry card ----------------
@Composable
fun JournalEntryCard(
    date: LocalDate,
    e: JournalEntry,
    sym: String,
    rev: Int,
    startExpanded: Boolean = false,
    onEdit: (() -> Unit)? = null,
    onPnl: (() -> Unit)? = null,
    extra: (@Composable ColumnScope.() -> Unit)? = null
) {
    val ctx = LocalContext.current
    var expanded by remember(date) { mutableStateOf(startExpanded) }
    val p = remember(rev, date) { Store.pnl(ctx, date) }
    val mood = MOOD_EMOJI[(e.mood - 1).coerceIn(0, 4)]
    Card(Modifier.fillMaxWidth().clickable { expanded = !expanded }) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    dateShort(date) + "  " + mood + (if (e.photos.isNotEmpty()) "  📷${e.photos.size}" else ""),
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.titleSmall
                )
                if (p != null) {
                    Text(
                        fmtMoney(p, sym),
                        color = if (p > 0) Color(0xFF2E9E4F) else if (p < 0) Color(0xFFC62828) else Color.Unspecified,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(if (expanded) "▲" else "▼")
            }
            if (!expanded) {
                Text(
                    if (e.note.isEmpty()) "(no note)" else e.note,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text("Mindset $mood · ${PLAN_LABELS[e.plan.coerceIn(0, 2)]}", style = MaterialTheme.typography.bodyMedium)
                Text(
                    when (e.acted) {
                        1 -> "Gut feeling: acted on it ✅"
                        0 -> "Gut feeling: held back ✋"
                        else -> "Gut feeling: not tagged"
                    },
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    if (p != null) "P&L: ${fmtMoney(p, sym)}" else "P&L: not logged",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(if (e.note.isEmpty()) "(no note)" else e.note, style = MaterialTheme.typography.bodyMedium)
                e.photos.forEach { name ->
                    key(name) {
                        val bmp = remember(name) { Photos.bitmap(ctx, name, 1200)?.asImageBitmap() }
                        if (bmp != null) {
                            Image(
                                bmp,
                                contentDescription = null,
                                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.FillWidth
                            )
                        }
                    }
                }
            }
            extra?.invoke(this)
            if (expanded && (onEdit != null || onPnl != null)) {
                Row {
                    if (onPnl != null) TextButton(onClick = onPnl) { Text("Edit P&L") }
                    if (onEdit != null) TextButton(onClick = onEdit) { Text("✏️ Edit entry") }
                }
            }
        }
    }
}

@Composable
fun PhotoThumb(name: String, onRemove: () -> Unit) {
    val ctx = LocalContext.current
    val bmp = remember(name) { Photos.bitmap(ctx, name, 400)?.asImageBitmap() }
    Box {
        if (bmp != null) {
            Image(
                bmp,
                contentDescription = null,
                modifier = Modifier.size(90.dp).clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Crop
            )
        }
        Text(
            "✕",
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(2.dp)
                .background(Color(0x99000000), CircleShape)
                .clickable { onRemove() }
                .padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

// ---------------- Write tab ----------------
@Composable
fun JournalTab(
    tick: Int,
    tracked: Set<String>,
    date: LocalDate,
    onEdit: (LocalDate) -> Unit,
    onToday: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val today = LocalDate.now()
    val isToday = date == today
    var rev by remember { mutableIntStateOf(0) }
    var early by remember { mutableStateOf(false) }
    val inWindow = remember(tick) { LocalTime.now().hour == 23 }
    val entry = remember(rev, tick) { Store.journalEntry(ctx, date) }
    var mood by remember(entry) { mutableIntStateOf(entry?.mood ?: 3) }
    var plan by remember(entry) { mutableIntStateOf(entry?.plan ?: 1) }
    var acted by remember(entry) { mutableIntStateOf(entry?.acted ?: -1) }
    var note by remember(entry) { mutableStateOf(entry?.note ?: "") }
    var photos by remember(entry) { mutableStateOf(entry?.photos ?: emptyList<String>()) }
    val sym = remember(tick) { Store.currency(ctx) }
    var showTrades by remember { mutableStateOf(false) }
    val dayPnl = remember(rev, tick, showTrades) { Store.pnl(ctx, date) }
    val dayTrades = remember(rev, tick, showTrades) { Store.trades(ctx, date).size }
    if (showTrades) TradesDialog(date, sym, { showTrades = false; rev++ }) { rev++ }
    val days14 = remember(tick) { (13 downTo 0).map { today.minusDays(it.toLong()) } }
    val scoreThis = remember(tick, rev) { Store.avgScore(ctx, tracked, days14[7], days14[13]) }
    val scoreLast = remember(tick, rev) { Store.avgScore(ctx, tracked, days14[0], days14[6]) }
    val planThis = remember(tick, rev) { Store.avgPlan(ctx, days14[7], days14[13]) }
    val planLast = remember(tick, rev) { Store.avgPlan(ctx, days14[0], days14[6]) }
    val recent = remember(tick, rev) { Store.allJournal(ctx).filter { it.first != date }.take(8) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                val names = withContext(Dispatchers.IO) { uris.mapNotNull { Photos.save(ctx, date, it) } }
                photos = photos + names
            }
        }
    }

    TabList {
        item {
            Text("Journal 📓", style = MaterialTheme.typography.headlineMedium)
            if (isToday) Text("A quick end-of-day check-in. It opens at 11:00 pm and you get a reminder.")
        }
        if (!isToday) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Editing ${dateShort(date)}", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        TextButton(onClick = onToday) { Text("Back to today") }
                    }
                }
            }
        }
        if (isToday && !inWindow && entry == null && !early) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("🌙 The journal opens at 11:00 pm tonight.")
                        TextButton(onClick = { early = true }) { Text("Write early") }
                    }
                }
            }
        } else {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("How was your trading mindset?", style = MaterialTheme.typography.titleSmall)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            MOOD_EMOJI.forEachIndexed { i, emoji ->
                                if (mood == i + 1) Button(
                                    onClick = { mood = i + 1 },
                                    modifier = Modifier.weight(1f).height(48.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) { Text(emoji, fontSize = 22.sp) }
                                else OutlinedButton(
                                    onClick = { mood = i + 1 },
                                    modifier = Modifier.weight(1f).height(48.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) { Text(emoji, fontSize = 22.sp) }
                            }
                        }
                        Text("Did you stick to your plan?", style = MaterialTheme.typography.titleSmall)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(2 to "Yes ✅", 1 to "Partly 😅", 0 to "No ❌").forEach { (v, label) ->
                                if (plan == v) Button(
                                    onClick = { plan = v },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) { Text(label, maxLines = 1) }
                                else OutlinedButton(
                                    onClick = { plan = v },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) { Text(label, maxLines = 1) }
                            }
                        }
                        Text("Did you act on your gut feeling?", style = MaterialTheme.typography.titleSmall)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(1 to "Acted ✅", 0 to "Held back ✋", -1 to "N/A").forEach { (v, label) ->
                                if (acted == v) Button(
                                    onClick = { acted = v },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) { Text(label, maxLines = 1) }
                                else OutlinedButton(
                                    onClick = { acted = v },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) { Text(label, maxLines = 1) }
                            }
                        }
                        Text("P&L for this day", style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (dayPnl == null) "No trades logged yet."
                            else "${fmtMoney(dayPnl, sym)} from $dayTrades trade${if (dayTrades == 1) "" else "s"}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        OutlinedButton(onClick = { showTrades = true }) { Text("📈 View / add trades") }
                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            label = { Text("What did you feel or see? What will you fix?") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("Photos (chart screenshots)", style = MaterialTheme.typography.titleSmall)
                        if (photos.isNotEmpty()) {
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                photos.forEach { name ->
                                    key(name) {
                                        PhotoThumb(name) {
                                            photos = photos - name
                                            if (name !in (entry?.photos ?: emptyList())) Photos.delete(ctx, name)
                                        }
                                    }
                                }
                            }
                        }
                        OutlinedButton(onClick = { picker.launch("image/*") }) { Text("📷 Add photos") }
                        Button(
                            onClick = {
                                val old = entry?.photos ?: emptyList()
                                (old - photos.toSet()).forEach { Photos.delete(ctx, it) }
                                Store.saveJournal(ctx, date, JournalEntry(mood, plan, note.trim(), acted, photos))
                                rev++
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (entry == null) "Save entry" else "Update entry") }
                        if (entry != null) {
                            Text("Saved ✔", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        if (isToday) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Habit progress 📈", style = MaterialTheme.typography.titleMedium)
                        TrendRow("Checklist score", scoreThis, scoreLast)
                        TrendRow("Plan discipline", planThis, planLast)
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Mood, last 7 days", style = MaterialTheme.typography.titleMedium)
                        Row(Modifier.fillMaxWidth()) {
                            days14.takeLast(7).forEach { d ->
                                val e = Store.journalEntry(ctx, d)
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        d.dayOfWeek.getDisplayName(DayStyle.SHORT, Locale.getDefault()),
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        if (e != null) MOOD_EMOJI[(e.mood - 1).coerceIn(0, 4)] else "·",
                                        fontSize = 22.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        if (recent.isNotEmpty()) {
            item { Text("Recent entries (tap to open)", style = MaterialTheme.typography.titleMedium) }
            items(recent, key = { it.first.toString() }) { (d, e) ->
                JournalEntryCard(d, e, sym, rev, onEdit = { onEdit(d) })
            }
        }
    }
}

// ---------------- Month tab ----------------
@Composable
fun JournalMonthTab(tick: Int, onEdit: (LocalDate) -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val scope = rememberCoroutineScope()
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var rev by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<LocalDate?>(null) }
    var editPnl by remember { mutableStateOf<LocalDate?>(null) }
    val sym = remember(tick, rev) { Store.currency(ctx) }
    val entries = remember(ym, rev, tick) {
        (1..ym.lengthOfMonth()).mapNotNull { day ->
            val d = ym.atDay(day)
            Store.journalEntry(ctx, d)?.let { d to it }
        }
    }
    val monthName = ym.month.getDisplayName(DayStyle.FULL, Locale.getDefault()) + " " + ym.year
    val avgMood = if (entries.isEmpty()) 0.0 else entries.map { it.second.mood }.average()
    val followed = entries.count { it.second.plan == 2 }
    val actedN = entries.count { it.second.acted == 1 }
    val heldN = entries.count { it.second.acted == 0 }
    val photoN = entries.sumOf { it.second.photos.size }

    val ep = editPnl
    if (ep != null) {
        TradesDialog(ep, sym, { editPnl = null; rev++ }) { rev++ }
    }

    TabList {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { ym = ym.minusMonths(1); selected = null }) { Text("◀") }
                Text(
                    monthName,
                    Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleLarge
                )
                TextButton(
                    onClick = { ym = ym.plusMonths(1); selected = null },
                    enabled = ym < YearMonth.now()
                ) { Text("▶") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${entries.size} journal entries", style = MaterialTheme.typography.titleMedium)
                    if (entries.isNotEmpty()) {
                        val moodIdx = (Math.round(avgMood).toInt() - 1).coerceIn(0, 4)
                        Text("Average mood ${MOOD_EMOJI[moodIdx]} (${String.format(Locale.US, "%.1f", avgMood)} of 5)")
                        Text("Followed the plan: $followed of ${entries.size} days")
                        Text("Gut feeling: acted $actedN · held back $heldN")
                        if (photoN > 0) Text("📷 $photoN photos attached")
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { activity?.let { launchSharePdf(it, ym, scope) } },
                            modifier = Modifier.weight(1f)
                        ) { Text("Share PDF") }
                        OutlinedButton(
                            onClick = { activity?.let { printMonthReport(it, ym) } },
                            modifier = Modifier.weight(1f)
                        ) { Text("Print") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    JournalCalendar(ym, rev, selected) { selected = it }
                    Text("Tap a day to open its entry.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            val sel = selected
            if (sel != null) {
                val e = entries.firstOrNull { it.first == sel }?.second
                if (e != null) {
                    JournalEntryCard(
                        sel, e, sym, rev,
                        startExpanded = true,
                        onEdit = { onEdit(sel) },
                        onPnl = { editPnl = sel }
                    )
                } else {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("No entry on ${dateShort(sel)}.")
                            Button(onClick = { onEdit(sel) }) { Text("Write an entry for this day") }
                        }
                    }
                }
            }
        }
        if (entries.isNotEmpty()) {
            item { Text("All entries this month", style = MaterialTheme.typography.titleMedium) }
            items(entries.reversed().filter { it.first != selected }, key = { it.first.toString() }) { (d, e) ->
                JournalEntryCard(d, e, sym, rev, onEdit = { onEdit(d) }, onPnl = { editPnl = d })
            }
        }
    }
}

@Composable
fun JournalCalendar(ym: YearMonth, rev: Int, selected: LocalDate?, onPick: (LocalDate) -> Unit) {
    val ctx = LocalContext.current
    val lead = ym.atDay(1).dayOfWeek.value - 1
    val len = ym.lengthOfMonth()
    val rows = (lead + len + 6) / 7
    val today = LocalDate.now()
    val primary = MaterialTheme.colorScheme.primary
    val outline = MaterialTheme.colorScheme.outline
    val filled = MaterialTheme.colorScheme.primaryContainer
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("M", "T", "W", "T", "F", "S", "S").forEach {
                Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp)
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (col in 0 until 7) {
                    val dayNum = r * 7 + col - lead + 1
                    if (dayNum < 1 || dayNum > len) {
                        Spacer(Modifier.weight(1f).aspectRatio(1f))
                    } else {
                        val d = ym.atDay(dayNum)
                        val e = remember(rev, d) { Store.journalEntry(ctx, d) }
                        val shape = RoundedCornerShape(8.dp)
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .background(if (e != null) filled else Color.Transparent, shape)
                                .then(
                                    if (selected == d) Modifier.border(2.dp, primary, shape)
                                    else if (d == today) Modifier.border(1.dp, outline, shape)
                                    else Modifier
                                )
                                .clickable { onPick(d) },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$dayNum", fontSize = 11.sp)
                                if (e != null) {
                                    Text(MOOD_EMOJI[(e.mood - 1).coerceIn(0, 4)], fontSize = 16.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
