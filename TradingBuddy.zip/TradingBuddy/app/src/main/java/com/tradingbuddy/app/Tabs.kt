package com.tradingbuddy.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.TextStyle as DayStyle
import java.util.Locale
import kotlin.math.abs

private fun dayShort(d: LocalDate) = d.dayOfWeek.getDisplayName(DayStyle.SHORT, Locale.getDefault())

// ---------------- Checklist tab ----------------
@Composable
fun ChecklistTab(tick: Int, tracked: Set<String>, labelMap: Map<String, String>, goSettings: () -> Unit) {
    val ctx = LocalContext.current
    val apps = tracked.sortedBy { labelMap[it] ?: it }
    var selState by remember { mutableStateOf<String?>(null) }
    val s0 = selState
    val pkg = if (s0 != null && s0 in tracked) s0 else apps.firstOrNull()
    var rev by remember { mutableIntStateOf(0) }
    var newItem by remember { mutableStateOf("") }

    if (pkg == null) {
        TabList {
            item { Text("Checklist ✅", style = MaterialTheme.typography.headlineMedium) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Pick the apps you want to track first, then each one gets its own checklist.")
                        Button(onClick = goSettings) { Text("Pick apps") }
                    }
                }
            }
        }
        return
    }

    val entries = remember(pkg, rev) { Store.checklist(ctx, pkg) }
    val done = remember(pkg, rev, tick) { Store.checkedOn(ctx, LocalDate.now(), pkg) }
    val score = Store.score(ctx, pkg, done)
    val used = remember(tick) { Store.usedToday(ctx, pkg) }
    val limit = remember(tick) { Store.dailyLimitMin(ctx) }

    TabList {
        item {
            Text("Checklist ✅", style = MaterialTheme.typography.headlineMedium)
            Text("Each app has its own list and score. It pops up the first time you open the app each day.")
        }
        item { AppChips(apps, pkg, labelMap) { selState = it } }
        item {
            ScoreCard(
                labelMap[pkg] ?: pkg, score, entries.count { it in done }, entries.size, used, limit
            )
        }
        items(entries, key = { it }) { text ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = text in done,
                    onCheckedChange = { on ->
                        Store.setChecked(ctx, pkg, if (on) done + text else done - text)
                        rev++
                    }
                )
                Text(text, Modifier.weight(1f))
                TextButton(onClick = {
                    Store.setChecklist(ctx, pkg, entries - text)
                    rev++
                }) { Text("✕") }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newItem,
                    onValueChange = { newItem = it },
                    label = { Text("New checklist item") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    val t = newItem.trim()
                    if (t.isNotEmpty()) {
                        Store.setChecklist(ctx, pkg, entries + t)
                        newItem = ""
                        rev++
                    }
                }) { Text("Add") }
            }
        }
        item {
            TextButton(onClick = {
                Store.setChecklist(ctx, pkg, DEFAULT_CHECKLIST)
                rev++
            }) { Text("Reset to default list") }
        }
    }
}

// ---------------- Tracker tab ----------------
@Composable
fun TrackerTab(tick: Int, tracked: Set<String>, labelMap: Map<String, String>) {
    val ctx = LocalContext.current
    val apps = tracked.sortedBy { labelMap[it] ?: it }
    var selState by remember { mutableStateOf<String?>(null) }
    val s0 = selState
    val sel = if (s0 != null && s0 in tracked) s0 else null
    val dayLimit = remember(tick) { Store.dailyLimitMin(ctx) }
    val limitMs = dayLimit * 60_000L
    val days14 = remember(tick) { (13 downTo 0).map { LocalDate.now().minusDays(it.toLong()) } }
    val days7 = days14.takeLast(7)
    val streak = remember(tick) { Store.streak(ctx) }
    val yMax = remember(tick) { Store.dayMaxApp(ctx, LocalDate.now().minusDays(1)) }
    val pkgs: Collection<String> = if (sel != null) listOf(sel) else tracked
    val scoreVals = remember(tick, sel, tracked) {
        days14.map { d -> Store.avgScore(ctx, pkgs, d, d) ?: 0 }
    }
    val timeVals = remember(tick, sel, tracked) {
        days7.map { d ->
            if (sel == null) Store.dayTotal(ctx, d) else Store.dayApp(ctx, d, sel)
        }
    }
    val thisWeek = remember(tick, sel, tracked) {
        Store.avgScore(ctx, pkgs, days14[7], days14[13])
    }
    val lastWeek = remember(tick, sel, tracked) {
        Store.avgScore(ctx, pkgs, days14[0], days14[6])
    }
    val primary = MaterialTheme.colorScheme.primary
    val red = Color(0xFFC62828)

    TabList {
        item { Text("Tracker 📊", style = MaterialTheme.typography.headlineMedium) }
        item { AppChips(listOf<String?>(null) + apps, sel, labelMap) { selState = it } }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Daily score, last 14 days", style = MaterialTheme.typography.titleMedium)
                    BarChart(
                        values = scoreVals.map { it.toFloat() },
                        maxV = 100f,
                        colors = scoreVals.map { Color(scoreColor(maxOf(it, 1))) },
                        labels = days14.map { "${it.dayOfMonth}" },
                        subs = scoreVals.map { if (it > 0) "$it" else "–" }
                    )
                    TrendRow("Checklist habit", thisWeek, lastWeek)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Time on app, last 7 days", style = MaterialTheme.typography.titleMedium)
                    BarChart(
                        values = timeVals.map { it.toFloat() },
                        maxV = maxOf(timeVals.max(), if (sel != null) limitMs else 0L, 60_000L).toFloat(),
                        colors = timeVals.map { if (sel != null && limitMs > 0 && it > limitMs) red else primary },
                        labels = days7.map { dayShort(it) },
                        subs = timeVals.map { fmtShort(it) },
                        limit = if (sel != null && limitMs > 0) limitMs.toFloat() else null
                    )
                    Text(
                        if (sel == null) "Showing all tracked apps together. Pick an app to see its limit line."
                        else "Dashed line is your daily limit for this app.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🔥 $streak-day streak", style = MaterialTheme.typography.titleMedium)
                    Text("Days where every app stayed under its time limit", style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth()) {
                        BadgeItem("🌱", "1 day", streak >= 1, Modifier.weight(1f))
                        BadgeItem("🔥", "3 days", streak >= 3, Modifier.weight(1f))
                        BadgeItem("🏆", "7 days", streak >= 7, Modifier.weight(1f))
                        BadgeItem("👑", "30 days", streak >= 30, Modifier.weight(1f))
                        BadgeItem(
                            "😎", "Half hero",
                            dayLimit > 0 && yMax > 0 && yMax < limitMs / 2,
                            Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

