package com.tradingbuddy.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.TextStyle as DayStyle
import java.util.Locale

private fun dayShort(d: LocalDate) = d.dayOfWeek.getDisplayName(DayStyle.SHORT, Locale.getDefault())

// ---------------- Checklist tab ----------------
@Composable
fun ChecklistTab(tick: Int, tracked: Set<String>, labelMap: Map<String, String>, goSettings: () -> Unit) {
    val ctx = LocalContext.current
    val apps = tracked.sortedBy { labelMap[it] ?: it }
    var selState by remember { mutableStateOf<String?>(null) }
    val s0 = selState
    val pkg = if (s0 != null && s0 in tracked) s0 else apps.firstOrNull()
    var rev by remember { mutableIntStateOf(0) }
    var newItem by remember { mutableStateOf("") }

    if (pkg == null) {
        TabList {
            item { Text("Checklist ✅", style = MaterialTheme.typography.headlineMedium) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Pick the apps you want to track first, then each one gets its own checklist.")
                        Button(onClick = goSettings) { Text("Pick apps") }
                    }
                }
            }
        }
        return
    }

    val entries = remember(pkg, rev) { Store.checklist(ctx, pkg) }
    val done = remember(pkg, rev, tick) { Store.checkedOn(ctx, LocalDate.now(), pkg) }
    val score = Store.score(ctx, pkg, done)
    val used = remember(tick) { Store.usedToday(ctx, pkg) }
    val limit = remember(tick) { Store.dailyLimitMin(ctx) }

    TabList {
        item {
            Text("Checklist ✅", style = MaterialTheme.typography.headlineMedium)
            Text("Each app has its own list and score. It pops up the first time you open the app each day.")
        }
        item { AppChips(apps, pkg, labelMap) { selState = it } }
        item {
            ScoreCard(
                labelMap[pkg] ?: pkg, score, entries.count { it in done }, entries.size, used, limit
            )
        }
        items(entries, key = { it }) { text ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = text in done,
                    onCheckedChange = { on ->
                        Store.setChecked(ctx, pkg, if (on) done + text else done - text)
                        rev++
                    }
                )
                Text(text, Modifier.weight(1f))
                TextButton(onClick = {
                    Store.setChecklist(ctx, pkg, entries - text)
                    rev++
                }) { Text("✕") }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newItem,
                    onValueChange = { newItem = it },
                    label = { Text("New checklist item") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    val t = newItem.trim()
                    if (t.isNotEmpty()) {
                        Store.setChecklist(ctx, pkg, entries + t)
                        newItem = ""
                        rev++
                    }
                }) { Text("Add") }
            }
        }
        item {
            TextButton(onClick = {
                Store.setChecklist(ctx, pkg, DEFAULT_CHECKLIST)
                rev++
            }) { Text("Reset to default list") }
        }
    }
}

// ---------------- Tracker tab ----------------
@Composable
fun TrackerTab(tick: Int, tracked: Set<String>, labelMap: Map<String, String>) {
    val ctx = LocalContext.current
    val apps = tracked.sortedBy { labelMap[it] ?: it }
    var selState by remember { mutableStateOf<String?>(null) }
    val s0 = selState
    val sel = if (s0 != null && s0 in tracked) s0 else null
    val dayLimit = remember(tick) { Store.dailyLimitMin(ctx) }
    val limitMs = dayLimit * 60_000L
    val days14 = remember(tick) { (13 downTo 0).map { LocalDate.now().minusDays(it.toLong()) } }
    val days7 = days14.takeLast(7)
    val streak = remember(tick) { Store.streak(ctx) }
    val yMax = remember(tick) { Store.dayMaxApp(ctx, LocalDate.now().minusDays(1)) }
    val pkgs: Collection<String> = if (sel != null) listOf(sel) else tracked
    val scoreVals = remember(tick, sel, tracked) {
        days14.map { d -> Store.avgScore(ctx, pkgs, d, d) ?: 0 }
    }
    val timeVals = remember(tick, sel, tracked) {
        days7.map { d ->
            if (sel == null) Store.dayTotal(ctx, d) else Store.dayApp(ctx, d, sel)
        }
    }
    val thisWeek = remember(tick, sel, tracked) {
        Store.avgScore(ctx, pkgs, days14[7], days14[13])
    }
    val lastWeek = remember(tick, sel, tracked) {
        Store.avgScore(ctx, pkgs, days14[0], days14[6])
    }
    val primary = MaterialTheme.colorScheme.primary
    val red = Color(0xFFC62828)

    TabList {
        item { Text("Tracker 📊", style = MaterialTheme.typography.headlineMedium) }
        item { AppChips(listOf<String?>(null) + apps, sel, labelMap) { selState = it } }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Daily score, last 14 days", style = MaterialTheme.typography.titleMedium)
                    BarChart(
                        values = scoreVals.map { it.toFloat() },
                        maxV = 100f,
                        colors = scoreVals.map { Color(scoreColor(maxOf(it, 1))) },
                        labels = days14.map { "${it.dayOfMonth}" },
                        subs = scoreVals.map { if (it > 0) "$it" else "–" }
                    )
                    TrendRow("Checklist habit", thisWeek, lastWeek)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Time on app, last 7 days", style = MaterialTheme.typography.titleMedium)
                    BarChart(
                        values = timeVals.map { it.toFloat() },
                        maxV = maxOf(timeVals.max(), if (sel != null) limitMs else 0L, 60_000L).toFloat(),
                        colors = timeVals.map { if (sel != null && limitMs > 0 && it > limitMs) red else primary },
                        labels = days7.map { dayShort(it) },
                        subs = timeVals.map { fmtShort(it) },
                        limit = if (sel != null && limitMs > 0) limitMs.toFloat() else null
                    )
                    Text(
                        if (sel == null) "Showing all tracked apps together. Pick an app to see its limit line."
                        else "Dashed line is your daily limit for this app.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🔥 $streak-day streak", style = MaterialTheme.typography.titleMedium)
                    Text("Days where every app stayed under its time limit", style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth()) {
                        BadgeItem("🌱", "1 day", streak >= 1, Modifier.weight(1f))
                        BadgeItem("🔥", "3 days", streak >= 3, Modifier.weight(1f))
                        BadgeItem("🏆", "7 days", streak >= 7, Modifier.weight(1f))
                        BadgeItem("👑", "30 days", streak >= 30, Modifier.weight(1f))
                        BadgeItem(
                            "😎", "Half hero",
                            dayLimit > 0 && yMax > 0 && yMax < limitMs / 2,
                            Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

// ---------------- Journal tab ----------------
@Composable
fun JournalTab(tick: Int, tracked: Set<String>) {
    val ctx = LocalContext.current
    val today = LocalDate.now()
    var rev by remember { mutableIntStateOf(0) }
    var early by remember { mutableStateOf(false) }
    val inWindow = remember(tick) { LocalTime.now().hour == 23 }
    val entry = remember(rev, tick) { Store.journalEntry(ctx, today) }
    var mood by remember(entry) { mutableIntStateOf(entry?.mood ?: 3) }
    var plan by remember(entry) { mutableIntStateOf(entry?.plan ?: 1) }
    var note by remember(entry) { mutableStateOf(entry?.note ?: "") }
    val days14 = remember(tick) { (13 downTo 0).map { today.minusDays(it.toLong()) } }
    val moods = listOf("😡", "😕", "😐", "🙂", "🤩")
    val planText = listOf("Broke the plan ❌", "Partly 😅", "Followed the plan ✅")
    val scoreThis = remember(tick, rev) { Store.avgScore(ctx, tracked, days14[7], days14[13]) }
    val scoreLast = remember(tick, rev) { Store.avgScore(ctx, tracked, days14[0], days14[6]) }
    val planThis = remember(tick, rev) { Store.avgPlan(ctx, days14[7], days14[13]) }
    val planLast = remember(tick, rev) { Store.avgPlan(ctx, days14[0], days14[6]) }
    val recent = remember(tick, rev) {
        days14.reversed().mapNotNull { d -> Store.journalEntry(ctx, d)?.let { d to it } }.take(5)
    }

    TabList {
        item {
            Text("Journal 📓", style = MaterialTheme.typography.headlineMedium)
            Text("A 30-second end-of-day check-in. Opens at 11:00 pm and you get a reminder.")
        }
        if (!inWindow && entry == null && !early) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("🌙 The journal opens at 11:00 pm tonight.")
                        TextButton(onClick = { early = true }) { Text("Write early") }
                    }
                }
            }
        } else {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("How was your trading mindset today?", style = MaterialTheme.typography.titleSmall)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            moods.forEachIndexed { i, emoji ->
                                val on = mood == i + 1
                                if (on) Button(
                                    onClick = { mood = i + 1 },
                                    modifier = Modifier.weight(1f).height(48.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) { Text(emoji, fontSize = 22.sp) }
                                else OutlinedButton(
                                    onClick = { mood = i + 1 },
                                    modifier = Modifier.weight(1f).height(48.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) { Text(emoji, fontSize = 22.sp) }
                            }
                        }
                        Text("Did you stick to your plan?", style = MaterialTheme.typography.titleSmall)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(2 to "Yes ✅", 1 to "Partly 😅", 0 to "No ❌").forEach { (v, label) ->
                                if (plan == v) Button(
                                    onClick = { plan = v },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) { Text(label, maxLines = 1) }
                                else OutlinedButton(
                                    onClick = { plan = v },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) { Text(label, maxLines = 1) }
                            }
                        }
                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            label = { Text("What went well? What will you fix?") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                Store.saveJournal(ctx, today, JournalEntry(mood, plan, note.trim()))
                                rev++
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (entry == null) "Save today's entry" else "Update entry") }
                        if (entry != null) Text("Saved ✔ You can edit it until midnight.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Habit progress 📈", style = MaterialTheme.typography.titleMedium)
                    TrendRow("Checklist score", scoreThis, scoreLast)
                    TrendRow("Plan discipline", planThis, planLast)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Mood, last 7 days", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth()) {
                        days14.takeLast(7).forEach { d ->
                            val e = Store.journalEntry(ctx, d)
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(dayShort(d), fontSize = 11.sp)
                                Text(if (e != null) moods[(e.mood - 1).coerceIn(0, 4)] else "·", fontSize = 22.sp)
                            }
                        }
                    }
                }
            }
        }
        if (recent.isNotEmpty()) {
            item { Text("Recent entries", style = MaterialTheme.typography.titleMedium) }
            items(recent, key = { it.first.toString() }) { (d, e) ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            "${dayShort(d)} ${d.dayOfMonth}  ${moods[(e.mood - 1).coerceIn(0, 4)]}  ·  ${planText[e.plan.coerceIn(0, 2)]}",
                            style = MaterialTheme.typography.titleSmall
                        )
                        if (e.note.isNotEmpty()) Text(e.note, maxLines = 3, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
