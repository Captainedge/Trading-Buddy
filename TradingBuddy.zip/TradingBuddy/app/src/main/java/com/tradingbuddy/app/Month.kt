package com.tradingbuddy.app

import android.app.Activity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle as DayStyle
import java.util.Locale
import kotlin.math.abs

private val GREEN = Color(0xFF2E9E4F)
private val RED = Color(0xFFC62828)
private val GRAY = Color(0xFF9E9E9E)
private val GOLD = Color(0xFFFFB300)
private val BLUE = Color(0xFF1E88E5)
private val EVAL_LABELS = listOf("⏳ Active", "✅ Passed", "❌ Failed", "💰 Funded")

// Daily / Monthly switch for the tracker tab
@Composable
fun TrackerHost(tick: Int, tracked: Set<String>, labelMap: Map<String, String>) {
    var mode by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Daily", "Monthly").forEachIndexed { i, name ->
                if (mode == i) Button(onClick = { mode = i }, modifier = Modifier.weight(1f)) { Text(name) }
                else OutlinedButton(onClick = { mode = i }, modifier = Modifier.weight(1f)) { Text(name) }
            }
        }
        Box(Modifier.weight(1f)) {
            if (mode == 0) TrackerTab(tick, tracked, labelMap) else MonthTab(tick)
        }
    }
}

@Composable
fun MonthTab(tick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var rev by remember { mutableIntStateOf(0) }
    var editDay by remember { mutableStateOf<LocalDate?>(null) }
    var newEval by remember { mutableStateOf("") }
    val sym = remember(tick, rev) { Store.currency(ctx) }
    val stats = remember(ym, rev, tick) { Store.monthStats(ctx, ym) }
    val allEvals = remember(rev) { Store.evals(ctx) }
    val evals = allEvals.filter { e ->
        runCatching { YearMonth.from(LocalDate.parse(e.date)) == ym }.getOrDefault(false)
    }
    val monthName = ym.month.getDisplayName(DayStyle.FULL, Locale.getDefault()) + " " + ym.year
    val traded = stats.wins + stats.losses + stats.flat
    val winRate = if (traded > 0) stats.wins * 100 / traded else 0
    val journalDays = remember(ym, rev, tick) {
        (1..ym.lengthOfMonth()).count { Store.journalEntry(ctx, ym.atDay(it)) != null }
    }
    val avgScore = remember(ym, rev, tick) {
        Store.avgScore(ctx, Store.tracked(ctx), ym.atDay(1), ym.atEndOfMonth())
    }

    val ed = editDay
    if (ed != null) {
        TradesDialog(ed, sym, { editDay = null; rev++ }) { rev++ }
    }

    TabList {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { ym = ym.minusMonths(1) }) { Text("◀") }
                Text(
                    monthName,
                    Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleLarge
                )
                TextButton(onClick = { ym = ym.plusMonths(1) }, enabled = ym < YearMonth.now()) { Text("▶") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Month P&L", style = MaterialTheme.typography.titleSmall)
                    Text(
                        fmtMoney(stats.total, sym),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (stats.total > 0) GREEN else if (stats.total < 0) RED else Color.Unspecified
                    )
                    Text("🟢 ${stats.wins} win days · 🔴 ${stats.losses} loss days · ⚪ ${stats.flat} flat")
                    Text("Win rate: $winRate% of $traded logged days")
                    stats.best?.let { Text("Best day: ${it.first.dayOfMonth} (${fmtMoney(it.second, sym)})") }
                    stats.worst?.let { Text("Worst day: ${it.first.dayOfMonth} (${fmtMoney(it.second, sym)})") }
                    Text(
                        "📓 $journalDays journal entries" +
                            (avgScore?.let { " · ✅ avg checklist score $it" } ?: ""),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("P&L calendar 📅", style = MaterialTheme.typography.titleMedium)
                    CalendarGrid(ym, rev) { editDay = it }
                    Text("Tap a day to see, add or edit its trades.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Win / loss days 🥧", style = MaterialTheme.typography.titleMedium)
                    PieChart(
                        listOf(
                            Triple("Winning days", stats.wins.toFloat(), GREEN),
                            Triple("Losing days", stats.losses.toFloat(), RED),
                            Triple("Break-even", stats.flat.toFloat(), GRAY)
                        )
                    )
                    if (evals.isNotEmpty()) {
                        Text("Eval results 🥧", style = MaterialTheme.typography.titleMedium)
                        PieChart(
                            listOf(
                                Triple("Passed", evals.count { it.status == 1 }.toFloat(), GREEN),
                                Triple("Funded", evals.count { it.status == 3 }.toFloat(), GOLD),
                                Triple("Failed", evals.count { it.status == 2 }.toFloat(), RED),
                                Triple("Active", evals.count { it.status == 0 }.toFloat(), BLUE)
                            )
                        )
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Evals & funded 💰", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "This month: ✅ ${evals.count { it.status == 1 }} passed · 💰 ${evals.count { it.status == 3 }} funded · ❌ ${evals.count { it.status == 2 }} failed",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "All time: ✅ ${allEvals.count { it.status == 1 }} passed · 💰 ${allEvals.count { it.status == 3 }} funded",
                        style = MaterialTheme.typography.bodySmall
                    )
                    evals.forEach { e ->
                        key(e.id) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(e.name, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                                    Text(e.date, style = MaterialTheme.typography.bodySmall)
                                    TextButton(onClick = {
                                        Store.saveEvals(ctx, allEvals.filter { it.id != e.id })
                                        rev++
                                    }) { Text("✕") }
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    EVAL_LABELS.forEachIndexed { i, label ->
                                        val set: () -> Unit = {
                                            Store.saveEvals(ctx, allEvals.map { if (it.id == e.id) it.copy(status = i) else it })
                                            rev++
                                        }
                                        if (e.status == i) Button(
                                            onClick = set,
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(0.dp)
                                        ) { Text(label, fontSize = 11.sp, maxLines = 1) }
                                        else OutlinedButton(
                                            onClick = set,
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(0.dp)
                                        ) { Text(label, fontSize = 11.sp, maxLines = 1) }
                                    }
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newEval,
                            onValueChange = { newEval = it },
                            label = { Text("New eval / account name") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = {
                            val n = newEval.trim()
                            if (n.isNotEmpty()) {
                                val date = if (ym == YearMonth.now()) LocalDate.now() else ym.atDay(1)
                                Store.saveEvals(ctx, allEvals + EvalItem(System.currentTimeMillis(), n, 0, date.toString()))
                                newEval = ""
                                rev++
                            }
                        }) { Text("Add") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Print or share 🖨️", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "One report with your P&L, pie charts, evals, journal entries and photos for this month. Print it, or share it as a PDF through WhatsApp, email, Drive and more.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { (ctx as? Activity)?.let { launchSharePdf(it, ym, scope) } },
                            modifier = Modifier.weight(1f)
                        ) { Text("Share PDF") }
                        OutlinedButton(
                            onClick = { (ctx as? Activity)?.let { printMonthReport(it, ym) } },
                            modifier = Modifier.weight(1f)
                        ) { Text("Print") }
                    }
                }
            }
        }
    }
}

@Composable
fun CalendarGrid(ym: YearMonth, rev: Int, onDay: (LocalDate) -> Unit) {
    val ctx = LocalContext.current
    val lead = ym.atDay(1).dayOfWeek.value - 1
    val len = ym.lengthOfMonth()
    val rows = (lead + len + 6) / 7
    val today = LocalDate.now()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("M", "T", "W", "T", "F", "S", "S").forEach {
                Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp)
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (col in 0 until 7) {
                    val dayNum = r * 7 + col - lead + 1
                    if (dayNum < 1 || dayNum > len) {
                        Spacer(Modifier.weight(1f).aspectRatio(1f))
                    } else {
                        val d = ym.atDay(dayNum)
                        val p = remember(rev, d) { Store.pnl(ctx, d) }
                        val bg = when {
                            p == null -> Color.Transparent
                            p > 0 -> GREEN.copy(alpha = 0.85f)
                            p < 0 -> RED.copy(alpha = 0.85f)
                            else -> GRAY.copy(alpha = 0.6f)
                        }
                        val shape = RoundedCornerShape(8.dp)
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .background(bg, shape)
                                .then(
                                    if (d == today) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, shape)
                                    else Modifier
                                )
                                .clickable { onDay(d) },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    "$dayNum",
                                    fontSize = 12.sp,
                                    color = if (p == null) Color.Unspecified else Color.White
                                )
                                if (p != null) Text(fmtCompact(p), fontSize = 9.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PieChart(slices: List<Triple<String, Float, Color>>, size: Dp = 130.dp) {
    val total = slices.sumOf { it.second.toDouble() }.toFloat()
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Canvas(Modifier.size(size)) {
            if (total <= 0f) {
                drawCircle(Color.Gray.copy(alpha = 0.3f))
            } else {
                var start = -90f
                slices.forEach { (_, v, col) ->
                    if (v > 0f) {
                        val sweep = 360f * v / total
                        drawArc(col, start, sweep, true)
                        start += sweep
                    }
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            slices.forEach { (name, v, col) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).background(col, CircleShape))
                    Spacer(Modifier.width(6.dp))
                    Text("$name: ${v.toInt()}", fontSize = 13.sp)
                }
            }
            if (total <= 0f) Text("No data yet", fontSize = 12.sp)
        }
    }
}

@Composable
fun PnlInput(text: String, onText: (String) -> Unit, sign: Int, onSign: (Int) -> Unit, sym: String) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (sign > 0) Button(onClick = { onSign(1) }, modifier = Modifier.weight(1f)) { Text("Profit +") }
            else OutlinedButton(onClick = { onSign(1) }, modifier = Modifier.weight(1f)) { Text("Profit +") }
            if (sign < 0) Button(
                onClick = { onSign(-1) },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = RED)
            ) { Text("Loss −") }
            else OutlinedButton(onClick = { onSign(-1) }, modifier = Modifier.weight(1f)) { Text("Loss −") }
        }
        OutlinedTextField(
            value = text,
            onValueChange = { v -> onText(v.filter { ch -> ch.isDigit() || ch == '.' }) },
            label = { Text("Amount ($sym), blank = none") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun PnlDialog(date: LocalDate, sym: String, current: Double?, onDismiss: () -> Unit, onSave: (Double?) -> Unit) {
    var sign by remember { mutableIntStateOf(if (current != null && current < 0) -1 else 1) }
    var text by remember {
        mutableStateOf(if (current != null) String.format(Locale.US, "%.2f", abs(current)) else "")
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("P&L for ${date.month.getDisplayName(DayStyle.SHORT, Locale.getDefault())} ${date.dayOfMonth}")
        },
        text = { PnlInput(text, { text = it }, sign, { sign = it }, sym) },
        confirmButton = {
            TextButton(onClick = {
                val v = text.toDoubleOrNull()
                onSave(if (v == null) null else v * sign)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
