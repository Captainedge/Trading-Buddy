package com.tradingbuddy.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun TabList(content: LazyListScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

// Colourful score card with animated number, colour and bouncing emoji
@Composable
fun ScoreCard(name: String, score: Int, done: Int, total: Int, used: Long, limitMin: Int) {
    val target = if (total == 0) Color(0xFF607D8B) else Color(scoreColor(score))
    val color by animateColorAsState(target, tween(600), label = "color")
    val shown by animateIntAsState(score, tween(700), label = "score")
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (score >= 90) 1.3f else 1.12f,
        animationSpec = infiniteRepeatable(tween(if (score < 40) 500 else 900), RepeatMode.Reverse),
        label = "pulse"
    )
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = color)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (total == 0) "No checklist yet. Add items in the Checks tab."
                    else "$done of $total checks · ${scoreLabel(score)}",
                    color = Color.White, fontSize = 13.sp
                )
                Text(
                    "⏱ ${fmtLong(used)}" + (if (limitMin > 0) " of ${limitMin}m" else ""),
                    color = Color.White, fontSize = 13.sp
                )
            }
            if (total > 0) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$shown", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                    Text(
                        scoreEmoji(score),
                        fontSize = 28.sp,
                        modifier = Modifier.graphicsLayer { scaleX = pulse; scaleY = pulse }
                    )
                }
            }
        }
    }
}

@Composable
fun AppChips(options: List<String?>, sel: String?, labelMap: Map<String, String>, onPick: (String?) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        options.forEach { p ->
            val name = if (p == null) "All" else (labelMap[p] ?: p)
            if (p == sel) Button(
                onClick = { onPick(p) },
                contentPadding = PaddingValues(horizontal = 12.dp)
            ) { Text(name) }
            else OutlinedButton(
                onClick = { onPick(p) },
                contentPadding = PaddingValues(horizontal = 12.dp)
            ) { Text(name) }
        }
    }
}

@Composable
fun BarChart(
    values: List<Float>,
    maxV: Float,
    colors: List<Color>,
    labels: List<String>,
    subs: List<String>,
    limit: Float? = null
) {
    val grid = MaterialTheme.colorScheme.outline
    Canvas(Modifier.fillMaxWidth().height(130.dp)) {
        val n = values.size
        val slot = size.width / n
        val bw = slot * 0.6f
        values.forEachIndexed { i, v ->
            val h = size.height * (v / maxV).coerceIn(0f, 1f)
            drawRect(colors[i], Offset(slot * i + (slot - bw) / 2f, size.height - h), Size(bw, h))
        }
        if (limit != null) {
            val y = size.height - size.height * (limit / maxV).coerceIn(0f, 1f)
            drawLine(
                grid, Offset(0f, y), Offset(size.width, y),
                strokeWidth = 3f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 14f))
            )
        }
    }
    Row(Modifier.fillMaxWidth()) {
        labels.forEachIndexed { i, l ->
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(l, fontSize = 9.sp)
                Text(subs[i], fontSize = 9.sp)
            }
        }
    }
}

@Composable
fun TrendRow(label: String, thisWeek: Int?, lastWeek: Int?) {
    val delta = if (thisWeek != null && lastWeek != null) thisWeek - lastWeek else null
    val arrow = when {
        delta == null -> ""
        delta > 0 -> "  ↗ +$delta"
        delta < 0 -> "  ↘ $delta"
        else -> "  → same"
    }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label + arrow, style = MaterialTheme.typography.titleSmall)
        Text("This week: ${thisWeek ?: "–"}", style = MaterialTheme.typography.bodySmall)
        LinearProgressIndicator(
            progress = { (thisWeek ?: 0) / 100f },
            modifier = Modifier.fillMaxWidth()
        )
        Text("Last week: ${lastWeek ?: "–"}", style = MaterialTheme.typography.bodySmall)
        LinearProgressIndicator(
            progress = { (lastWeek ?: 0) / 100f },
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.outline
        )
    }
}

@Composable
fun BadgeItem(emoji: String, label: String, earned: Boolean, modifier: Modifier) {
    Column(modifier.alpha(if (earned) 1f else 0.3f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, style = MaterialTheme.typography.headlineSmall)
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun Stepper(label: String, value: Int, step: Int, max: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        OutlinedButton(
            onClick = { onChange((value - step).coerceAtLeast(0)) },
            modifier = Modifier.size(44.dp),
            contentPadding = PaddingValues(0.dp)
        ) { Text("−") }
        Text(
            if (value == 0) "Off" else "$value m",
            modifier = Modifier.width(64.dp),
            textAlign = TextAlign.Center
        )
        OutlinedButton(
            onClick = { onChange((value + step).coerceAtMost(max)) },
            modifier = Modifier.size(44.dp),
            contentPadding = PaddingValues(0.dp)
        ) { Text("+") }
    }
}

@Composable
fun PermRow(label: String, ok: Boolean?, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label + if (ok == true) "  ✓" else "", Modifier.weight(1f))
        if (ok != true) TextButton(onClick = onClick) { Text(if (ok == null) "Open" else "Grant") }
    }
}
