package com.tradingbuddy.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

private class PdfWriter(private val doc: PdfDocument) {
    val pageW = 595
    val pageH = 842
    val margin = 40f
    val contentW: Float get() = pageW - 2 * margin
    private var page: PdfDocument.Page? = null
    lateinit var canvas: Canvas
    var y = 0f
    private var pageNo = 0
    private val footer = TextPaint().apply { textSize = 9f; color = Color.GRAY; isAntiAlias = true }

    init { newPage() }

    private fun drawFooter() {
        canvas.drawText("Trading Buddy · page $pageNo", margin, pageH - 20f, footer)
    }

    fun newPage() {
        page?.let { drawFooter(); doc.finishPage(it) }
        pageNo++
        val p = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
        page = p
        canvas = p.canvas
        y = margin
    }

    fun finish() {
        page?.let { drawFooter(); doc.finishPage(it) }
        page = null
    }

    fun ensure(h: Float) {
        if (y + h > pageH - margin - 10f) newPage()
    }

    fun gap(h: Float) { y += h }

    // Wraps text and flows it across pages line by line
    fun text(s: String, paint: TextPaint, x: Float = margin, width: Float = contentW) {
        if (s.isEmpty()) return
        val layout = StaticLayout.Builder.obtain(s, 0, s.length, paint, width.toInt()).build()
        for (i in 0 until layout.lineCount) {
            val top = layout.getLineTop(i).toFloat()
            val bottom = layout.getLineBottom(i).toFloat()
            ensure(bottom - top)
            canvas.save()
            canvas.translate(x, y - top)
            canvas.clipRect(0f, top, width, bottom)
            layout.draw(canvas)
            canvas.restore()
            y += bottom - top
        }
    }

    fun pie(slices: List<Triple<String, Float, Int>>, size: Float = 110f) {
        val total = slices.sumOf { it.second.toDouble() }.toFloat()
        ensure(size + 10f)
        val rect = RectF(margin, y, margin + size, y + size)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        if (total <= 0f) {
            p.color = 0xFFDDDDDD.toInt()
            canvas.drawOval(rect, p)
        } else {
            var start = -90f
            for ((_, v, col) in slices) {
                if (v > 0f) {
                    val sweep = 360f * v / total
                    p.color = col
                    canvas.drawArc(rect, start, sweep, true, p)
                    start += sweep
                }
            }
        }
        val lp = TextPaint().apply { textSize = 11f; isAntiAlias = true; color = Color.DKGRAY }
        var ly = y + 14f
        for ((name, v, col) in slices) {
            p.color = col
            canvas.drawRect(margin + size + 16f, ly - 9f, margin + size + 26f, ly + 1f, p)
            canvas.drawText("$name: ${v.toInt()}", margin + size + 32f, ly, lp)
            ly += 16f
        }
        y += size + 10f
    }

    fun image(bmp: Bitmap, maxW: Float = contentW, maxH: Float = 300f) {
        var w = maxW
        var h = bmp.height * w / bmp.width
        if (h > maxH) {
            h = maxH
            w = bmp.width * h / bmp.height
        }
        ensure(h + 6f)
        canvas.drawBitmap(bmp, null, RectF(margin, y, margin + w, y + h), Paint(Paint.FILTER_BITMAP_FLAG))
        y += h + 8f
    }

    fun row(cols: List<String>, xs: List<Float>, ws: List<Float>, paint: TextPaint, header: Boolean = false, colors: List<Int>? = null) {
        ensure(18f)
        if (header) {
            val bp = Paint().apply { color = 0xFFEEEEEE.toInt() }
            canvas.drawRect(margin, y - 2f, margin + contentW, y + 14f, bp)
        }
        val lineP = Paint().apply { color = 0xFFDDDDDD.toInt(); strokeWidth = 0.5f }
        canvas.drawLine(margin, y + 14f, margin + contentW, y + 14f, lineP)
        val old = paint.color
        cols.forEachIndexed { i, s ->
            val t = TextUtils.ellipsize(s, paint, ws[i], TextUtils.TruncateAt.END).toString()
            paint.color = colors?.get(i) ?: old
            canvas.drawText(t, margin + xs[i] + 2f, y + 10f, paint)
        }
        paint.color = old
        y += 16f
    }
}

private fun paint(size: Float, bold: Boolean = false, color: Int = Color.BLACK) =
    TextPaint().apply {
        textSize = size
        isFakeBoldText = bold
        isAntiAlias = true
        this.color = color
    }

// Builds a PDF with P&L, pie charts, evals, daily log and the full journal (with photos)
fun buildMonthPdf(c: Context, ym: YearMonth): File {
    val sym = Store.currency(c)
    val tracked = Store.tracked(c)
    val st = Store.monthStats(c, ym)
    val title = ym.month.getDisplayName(TextStyle.FULL, Locale.getDefault()) + " " + ym.year
    val traded = st.wins + st.losses + st.flat
    val winRate = if (traded > 0) st.wins * 100 / traded else 0
    val avgScore = Store.avgScore(c, tracked, ym.atDay(1), ym.atEndOfMonth())
    val evals = Store.evals(c).filter {
        runCatching { YearMonth.from(LocalDate.parse(it.date)) == ym }.getOrDefault(false)
    }
    val green = 0xFF2E9E4F.toInt()
    val red = 0xFFC62828.toInt()
    val gray = 0xFF9E9E9E.toInt()
    val statusText = listOf("In progress", "Passed", "Failed", "Funded", "Blown")
    val planText = listOf("Broke plan", "Partly", "Followed plan")

    val doc = PdfDocument()
    val w = PdfWriter(doc)
    val h1 = paint(20f, true)
    val h2 = paint(14f, true)
    val body = paint(11f)
    val bold = paint(11f, true)
    val muted = paint(10f, false, Color.GRAY)
    val small = paint(10f)

    w.text("Trading Buddy · $title", h1)
    w.text("Monthly P&L and journal report", muted)
    w.gap(10f)

    w.text("Summary", h2)
    w.gap(4f)
    w.text(
        fmtMoney(st.total, sym),
        paint(24f, true, if (st.total > 0) green else if (st.total < 0) red else Color.BLACK)
    )
    w.text("Win days ${st.wins} · Loss days ${st.losses} · Break-even ${st.flat} · Win rate $winRate% of $traded logged days", body)
    st.best?.let { w.text("Best day: ${it.first.dayOfMonth} (${fmtMoney(it.second, sym)})", body) }
    st.worst?.let { w.text("Worst day: ${it.first.dayOfMonth} (${fmtMoney(it.second, sym)})", body) }
    w.text("Average checklist score: ${avgScore ?: "–"}", body)
    w.gap(10f)

    w.text("Charts", h2)
    w.gap(4f)
    w.text("Win / loss days", bold)
    w.gap(2f)
    w.pie(
        listOf(
            Triple("Winning days", st.wins.toFloat(), green),
            Triple("Losing days", st.losses.toFloat(), red),
            Triple("Break-even days", st.flat.toFloat(), gray)
        )
    )
    if (evals.isNotEmpty()) {
        w.text("Eval results", bold)
        w.gap(2f)
        w.pie(
            listOf(
                Triple("Passed", evals.count { it.status == 1 }.toFloat(), green),
                Triple("Funded", evals.count { it.status == 3 }.toFloat(), 0xFFFFB300.toInt()),
                Triple("Failed", evals.count { it.status == 2 }.toFloat(), red),
                Triple("Blown", evals.count { it.status == 4 }.toFloat(), 0xFF6D1B1B.toInt()),
                Triple("In progress", evals.count { it.status == 0 }.toFloat(), 0xFF1E88E5.toInt())
            )
        )
    }
    w.gap(6f)

    w.text("Evals & funded accounts", h2)
    w.gap(4f)
    if (evals.isEmpty()) {
        w.text("No evals logged this month.", muted)
    } else {
        val xs = listOf(0f, 215f, 330f, 430f)
        val ws = listOf(210f, 110f, 95f, 85f)
        w.row(listOf("Name", "Status", "Date", "Cost"), xs, ws, bold, header = true)
        evals.forEach {
            w.row(
                listOf(
                    it.name, statusText[it.status.coerceIn(0, 4)], it.date,
                    if (it.cost > 0) fmtPlain(it.cost, sym) else "–"
                ),
                xs, ws, small
            )
        }
        w.gap(4f)
        w.text(
            "Fees paid ${fmtPlain(evals.sumOf { it.cost }, sym)} · payouts ${fmtPlain(evals.sumOf { it.payouts }, sym)} · net ${fmtMoney(evals.sumOf { it.payouts - it.cost }, sym)}",
            body
        )
    }
    w.gap(10f)

    w.text("Daily log", h2)
    w.gap(4f)
    val xs = listOf(0f, 62f, 150f, 205f, 262f, 400f)
    val ws = listOf(60f, 86f, 53f, 55f, 136f, 113f)
    w.row(listOf("Date", "P&L", "Score", "Mood", "Plan", "Acted on feeling"), xs, ws, bold, header = true)
    var rows = 0
    for (day in 1..ym.lengthOfMonth()) {
        val d = ym.atDay(day)
        val p = Store.pnl(c, d)
        val sc = Store.avgScore(c, tracked, d, d)
        val j = Store.journalEntry(c, d)
        if (p == null && sc == null && j == null) continue
        rows++
        val dayName = d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())
        val actedText = when (j?.acted) {
            1 -> "Acted"
            0 -> "Held back"
            else -> "–"
        }
        val pColor = if (p == null) Color.BLACK else if (p > 0) green else if (p < 0) red else Color.BLACK
        w.row(
            listOf(
                "$dayName $day",
                if (p != null) fmtMoney(p, sym) else "–",
                "${sc ?: "–"}",
                if (j != null) "${j.mood}/5" else "–",
                if (j != null) planText[j.plan.coerceIn(0, 2)] else "–",
                actedText
            ),
            xs, ws, small,
            colors = listOf(Color.BLACK, pColor, Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK)
        )
    }
    if (rows == 0) w.text("Nothing logged this month yet.", muted)
    w.gap(10f)

    w.ensure(60f)
    w.text("Journal", h2)
    w.gap(4f)
    var entries = 0
    for (day in 1..ym.lengthOfMonth()) {
        val d = ym.atDay(day)
        val j = Store.journalEntry(c, d) ?: continue
        entries++
        val dayName = d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())
        val p = Store.pnl(c, d)
        val actedText = when (j.acted) {
            1 -> " · Acted on the feeling"
            0 -> " · Held back"
            else -> ""
        }
        w.gap(6f)
        w.ensure(50f)
        w.text(
            "$dayName $day · Mood ${j.mood}/5 · ${planText[j.plan.coerceIn(0, 2)]}$actedText" +
                (if (p != null) " · P&L ${fmtMoney(p, sym)}" else ""),
            bold
        )
        w.text(if (j.note.isEmpty()) "(no note)" else j.note, body)
        j.photos.forEach { n ->
            Photos.bitmap(c, n, 900)?.let { bmp ->
                w.gap(4f)
                w.image(bmp)
                bmp.recycle()
            }
        }
    }
    if (entries == 0) w.text("No journal entries this month.", muted)
    w.gap(12f)
    w.text("Generated by Trading Buddy on ${LocalDate.now()}", muted)
    w.finish()

    val dir = File(c.cacheDir, "shared").apply { mkdirs() }
    val f = File(dir, "TradingBuddy_$ym.pdf")
    FileOutputStream(f).use { doc.writeTo(it) }
    doc.close()
    return f
}

// Builds the PDF in the background, then opens the share sheet
fun launchSharePdf(activity: Activity, ym: YearMonth, scope: CoroutineScope) {
    Toast.makeText(activity, "Preparing PDF…", Toast.LENGTH_SHORT).show()
    scope.launch {
        val file = try {
            withContext(Dispatchers.IO) { buildMonthPdf(activity, ym) }
        } catch (_: Exception) { null }
        if (file == null) {
            Toast.makeText(activity, "Couldn't create the PDF", Toast.LENGTH_LONG).show()
            return@launch
        }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND)
            .setType("application/pdf")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_SUBJECT, "Trading Buddy report $ym")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        activity.startActivity(Intent.createChooser(send, "Share report"))
    }
}
