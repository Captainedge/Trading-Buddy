package com.tradingbuddy.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Store.enabled(c) && hasUsageAccess(c) && Settings.canDrawOverlays(c)) {
            try {
                ContextCompat.startForegroundService(c, Intent(c, TrackerService::class.java))
            } catch (_: Exception) { }
        }
    }
}
