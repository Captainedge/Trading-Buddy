package com.tradingbuddy.app

import android.app.AppOpsManager
import android.content.Context
import android.os.Build
import android.os.Process
import org.json.JSONObject
import java.time.LocalDate

val DEFAULT_CHECKLIST = listOf(
    "Checked the economic calendar 📅",
    "Reviewed my trading plan 📝",
    "Defined my risk per trade 🛡️",
    "Stop-loss and target planned 🎯",
    "Calm and focused, no FOMO 🧘",
    "No revenge trades today 🚫"
)

data class JournalEntry(val mood: Int, val plan: Int, val note: String)

fun scoreColor(s: Int): Int = when {
    s >= 100 -> 0xFFAB47BC.toInt()
    s >= 80 -> 0xFF2E9E4F.toInt()
    s >= 60 -> 0xFF1E88E5.toInt()
    s >= 40 -> 0xFFFB8C00.toInt()
    else -> 0xFFE53935.toInt()
}

fun scoreEmoji(s: Int): String = when {
    s >= 100 -> "🏆"
    s >= 80 -> "😎"
    s >= 60 -> "🙂"
    s >= 40 -> "😐"
    else -> "😟"
}

fun scoreLabel(s: Int): String = when {
    s >= 100 -> "Perfect!"
    s >= 80 -> "Great"
    s >= 60 -> "Solid"
    s >= 40 -> "Getting there"
    else -> "Needs work"
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("tradingbuddy", Context.MODE_PRIVATE)
    private fun today() = LocalDate.now().toString()
    private val datedKey = Regex("^(?:d|a|ck|sc|j)_(\\d{4}-\\d{2}-\\d{2})")

    fun tracked(c: Context): Set<String> = sp(c).getStringSet("tracked", emptySet()) ?: emptySet()
    fun setTracked(c: Context, s: Set<String>) = sp(c).edit().putStringSet("tracked", HashSet(s)).apply()

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun pos(c: Context): Pair<Int, Int>? {
        val p = sp(c)
        return if (p.contains("ox")) Pair(p.getInt("ox", 0), p.getInt("oy", 0)) else null
    }
    fun setPos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("ox", x).putInt("oy", y).apply()

    fun bpos(c: Context): Pair<Int, Int>? {
        val p = sp(c)
        return if (p.contains("bx")) Pair(p.getInt("bx", 0), p.getInt("by", 0)) else null
    }
    fun setBpos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("bx", x).putInt("by", y).apply()

    fun dailyLimitMin(c: Context) = sp(c).getInt("limit_day", 60)
    fun setDailyLimitMin(c: Context, v: Int) = sp(c).edit().putInt("limit_day", v).apply()
    fun sessionLimitMin(c: Context) = sp(c).getInt("limit_sess", 20)
    fun setSessionLimitMin(c: Context, v: Int) = sp(c).edit().putInt("limit_sess", v).apply()

    fun touch(c: Context) {
        val p = sp(c)
        if (!p.contains("first")) p.edit().putString("first", today()).apply()
    }

    // Days the timer is active (ISO: 1 = Monday ... 7 = Sunday)
    fun daysOn(c: Context): Set<Int> =
        (sp(c).getString("days", null) ?: "1,2,3,4,5,6,7")
            .split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
    fun setDays(c: Context, s: Set<Int>) =
        sp(c).edit().putString("days", s.sorted().joinToString(",")).apply()
    fun scheduledToday(c: Context) = LocalDate.now().dayOfWeek.value in daysOn(c)

    // ---------- time tracking ----------
    fun dayApp(c: Context, d: LocalDate, pkg: String): Long = sp(c).getLong("a_${d}_$pkg", 0L)
    fun usedToday(c: Context, pkg: String): Long = dayApp(c, LocalDate.now(), pkg)
    fun dayTotal(c: Context, d: LocalDate): Long = sp(c).getLong("d_$d", 0L)

    fun dayMaxApp(c: Context, d: LocalDate): Long {
        val prefix = "a_${d}_"
        var m = 0L
        for ((k, v) in sp(c).all) if (k.startsWith(prefix)) m = maxOf(m, (v as? Long) ?: 0L)
        return m
    }

    fun add(c: Context, pkg: String, ms: Long) {
        val p = sp(c)
        val today = today()
        val e = p.edit()
        if (!p.contains("first")) e.putString("first", today)
        if (p.getString("pruned", "") != today) {
            val cutoff = LocalDate.now().minusDays(90).toString()
            p.all.keys
                .filter { k -> datedKey.find(k)?.groupValues?.get(1)?.let { it < cutoff } == true }
                .forEach { e.remove(it) }
            e.putString("pruned", today)
        }
        e.putLong("a_${today}_$pkg", p.getLong("a_${today}_$pkg", 0L) + ms)
        e.putLong("d_$today", p.getLong("d_$today", 0L) + ms)
        e.apply()
    }

    fun streak(c: Context): Int {
        val limit = dailyLimitMin(c) * 60_000L
        if (limit <= 0) return 0
        val days = daysOn(c)
        val firstStr = sp(c).getString("first", null) ?: today()
        val first = try { LocalDate.parse(firstStr) } catch (_: Exception) { LocalDate.now() }
        var d = LocalDate.now().minusDays(1)
        var n = 0
        while (!d.isBefore(first) && n < 365) {
            if (d.dayOfWeek.value in days) {
                if (dayMaxApp(c, d) <= limit) n++ else break
            }
            d = d.minusDays(1)
        }
        return n
    }

    // ---------- checklists and scores ----------
    fun checklist(c: Context, pkg: String): List<String> {
        val s = sp(c).getString("cl_$pkg", null) ?: return DEFAULT_CHECKLIST
        return s.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun setChecklist(c: Context, pkg: String, items: List<String>) {
        val clean = items.map { it.replace("\n", " ").trim() }.filter { it.isNotEmpty() }.distinct()
        sp(c).edit().putString("cl_$pkg", clean.joinToString("\n")).apply()
    }

    fun checkedOn(c: Context, d: LocalDate, pkg: String): Set<String> =
        (sp(c).getString("ck_${d}_$pkg", null) ?: "").split("\n").filter { it.isNotBlank() }.toSet()

    // Score from 1 to 100 (0 when the app has no checklist items)
    fun score(c: Context, pkg: String, done: Set<String> = checkedOn(c, LocalDate.now(), pkg)): Int {
        val entries = checklist(c, pkg)
        if (entries.isEmpty()) return 0
        val n = entries.count { it in done }
        return maxOf(1, 100 * n / entries.size)
    }

    fun setChecked(c: Context, pkg: String, done: Set<String>) {
        val today = today()
        val s = score(c, pkg, done)
        sp(c).edit()
            .putString("ck_${today}_$pkg", done.joinToString("\n"))
            .putInt("sc_${today}_$pkg", s)
            .apply()
    }

    fun scoreOn(c: Context, d: LocalDate, pkg: String): Int = sp(c).getInt("sc_${d}_$pkg", 0)

    fun shownToday(c: Context, pkg: String) = sp(c).getString("shown_$pkg", "") == today()
    fun setShown(c: Context, pkg: String) = sp(c).edit().putString("shown_$pkg", today()).apply()

    fun avgScore(c: Context, pkgs: Collection<String>, from: LocalDate, to: LocalDate): Int? {
        var sum = 0
        var n = 0
        var d = from
        while (!d.isAfter(to)) {
            for (p in pkgs) {
                val s = scoreOn(c, d, p)
                if (s > 0) { sum += s; n++ }
            }
            d = d.plusDays(1)
        }
        return if (n == 0) null else sum / n
    }

    // ---------- journal ----------
    fun journalEntry(c: Context, d: LocalDate): JournalEntry? {
        val s = sp(c).getString("j_$d", null) ?: return null
        return try {
            val o = JSONObject(s)
            JournalEntry(o.optInt("mood", 3), o.optInt("plan", 1), o.optString("note", ""))
        } catch (_: Exception) { null }
    }

    fun saveJournal(c: Context, d: LocalDate, e: JournalEntry) {
        val s = JSONObject().put("mood", e.mood).put("plan", e.plan).put("note", e.note).toString()
        sp(c).edit().putString("j_$d", s).apply()
    }

    fun avgPlan(c: Context, from: LocalDate, to: LocalDate): Int? {
        var sum = 0
        var n = 0
        var d = from
        while (!d.isAfter(to)) {
            journalEntry(c, d)?.let { sum += it.plan * 50; n++ }
            d = d.plusDays(1)
        }
        return if (n == 0) null else sum / n
    }

    fun journalNotified(c: Context) = sp(c).getString("jn_day", "") == today()
    fun setJournalNotified(c: Context) = sp(c).edit().putString("jn_day", today()).apply()
}

fun fmtClock(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

fun fmtLong(ms: Long): String {
    val m = ms / 60000
    return when {
        m >= 60 -> "${m / 60}h ${m % 60}m"
        m >= 1 -> "${m}m"
        else -> "${ms / 1000}s"
    }
}

fun fmtShort(ms: Long): String {
    val m = ms / 60000
    if (m < 60) return "${m}m"
    val r = "%02d".format(m % 60)
    return "${m / 60}h$r"
}

fun moodFor(ratio: Float): Pair<String, Int> = when {
    ratio < 0.5f -> "😎" to 0xCC2E7D32.toInt()
    ratio < 0.8f -> "🙂" to 0xCC9E9D24.toInt()
    ratio < 1f -> "😬" to 0xCCEF6C00.toInt()
    else -> "😱" to 0xCCC62828.toInt()
}

fun hasUsageAccess(c: Context): Boolean {
    val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    @Suppress("DEPRECATION")
    val mode = if (Build.VERSION.SDK_INT >= 29)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    else
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}
