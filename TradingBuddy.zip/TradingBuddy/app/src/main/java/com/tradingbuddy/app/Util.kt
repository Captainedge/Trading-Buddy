package com.tradingbuddy.app

import android.app.AppOpsManager
import android.content.Context
import android.os.Build
import android.os.Process
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale
import kotlin.math.abs

val DEFAULT_CHECKLIST = listOf(
    "Checked the economic calendar 📅",
    "Reviewed my trading plan 📝",
    "Defined my risk per trade 🛡️",
    "Stop-loss and target planned 🎯",
    "Calm and focused, no FOMO 🧘",
    "No revenge trades today 🚫"
)

// acted: 1 = acted on the feeling, 0 = held back, -1 = not tagged
data class JournalEntry(
    val mood: Int,
    val plan: Int,
    val note: String,
    val acted: Int = -1,
    val photos: List<String> = emptyList()
)

data class Trade(val time: Long, val amount: Double, val note: String)

// status: 0 = in progress, 1 = passed, 2 = failed, 3 = funded
data class EvalItem(val id: Long, val name: String, val status: Int, val date: String)

data class MonthStats(
    val total: Double,
    val wins: Int,
    val losses: Int,
    val flat: Int,
    val best: Pair<LocalDate, Double>?,
    val worst: Pair<LocalDate, Double>?
)

fun scoreColor(s: Int): Int = when {
    s >= 100 -> 0xFFAB47BC.toInt()
    s >= 80 -> 0xFF2E9E4F.toInt()
    s >= 60 -> 0xFF1E88E5.toInt()
    s >= 40 -> 0xFFFB8C00.toInt()
    else -> 0xFFE53935.toInt()
}

fun scoreEmoji(s: Int): String = when {
    s >= 100 -> "🏆"
    s >= 80 -> "😎"
    s >= 60 -> "🙂"
    s >= 40 -> "😐"
    else -> "😟"
}

fun scoreLabel(s: Int): String = when {
    s >= 100 -> "Perfect!"
    s >= 80 -> "Great"
    s >= 60 -> "Solid"
    s >= 40 -> "Getting there"
    else -> "Needs work"
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("tradingbuddy", Context.MODE_PRIVATE)
    private fun today() = LocalDate.now().toString()
    private val datedKey = Regex("^(?:d|a|ck)_(\\d{4}-\\d{2}-\\d{2})")

    fun tracked(c: Context): Set<String> = sp(c).getStringSet("tracked", emptySet()) ?: emptySet()
    fun setTracked(c: Context, s: Set<String>) = sp(c).edit().putStringSet("tracked", HashSet(s)).apply()

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun pos(c: Context): Pair<Int, Int>? {
        val p = sp(c)
        return if (p.contains("ox")) Pair(p.getInt("ox", 0), p.getInt("oy", 0)) else null
    }
    fun setPos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("ox", x).putInt("oy", y).apply()

    fun bpos(c: Context): Pair<Int, Int>? {
        val p = sp(c)
        return if (p.contains("bx")) Pair(p.getInt("bx", 0), p.getInt("by", 0)) else null
    }
    fun setBpos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("bx", x).putInt("by", y).apply()

    fun dailyLimitMin(c: Context) = sp(c).getInt("limit_day", 60)
    fun setDailyLimitMin(c: Context, v: Int) = sp(c).edit().putInt("limit_day", v).apply()
    fun sessionLimitMin(c: Context) = sp(c).getInt("limit_sess", 20)
    fun setSessionLimitMin(c: Context, v: Int) = sp(c).edit().putInt("limit_sess", v).apply()

    fun touch(c: Context) {
        val p = sp(c)
        if (!p.contains("first")) p.edit().putString("first", today()).apply()
    }

    // Days the timer is active (ISO: 1 = Monday ... 7 = Sunday)
    fun daysOn(c: Context): Set<Int> =
        (sp(c).getString("days", null) ?: "1,2,3,4,5,6,7")
            .split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
    fun setDays(c: Context, s: Set<Int>) =
        sp(c).edit().putString("days", s.sorted().joinToString(",")).apply()
    fun scheduledToday(c: Context) = LocalDate.now().dayOfWeek.value in daysOn(c)

    // ---------- time tracking ----------
    fun dayApp(c: Context, d: LocalDate, pkg: String): Long = sp(c).getLong("a_${d}_$pkg", 0L)
    fun usedToday(c: Context, pkg: String): Long = dayApp(c, LocalDate.now(), pkg)
    fun dayTotal(c: Context, d: LocalDate): Long = sp(c).getLong("d_$d", 0L)

    fun dayMaxApp(c: Context, d: LocalDate): Long {
        val prefix = "a_${d}_"
        var m = 0L
        for ((k, v) in sp(c).all) if (k.startsWith(prefix)) m = maxOf(m, (v as? Long) ?: 0L)
        return m
    }

    fun add(c: Context, pkg: String, ms: Long) {
        val p = sp(c)
        val today = today()
        val e = p.edit()
        if (!p.contains("first")) e.putString("first", today)
        if (p.getString("pruned", "") != today) {
            val cutoff = LocalDate.now().minusDays(90).toString()
            p.all.keys
                .filter { k -> datedKey.find(k)?.groupValues?.get(1)?.let { it < cutoff } == true }
                .forEach { e.remove(it) }
            e.putString("pruned", today)
        }
        e.putLong("a_${today}_$pkg", p.getLong("a_${today}_$pkg", 0L) + ms)
        e.putLong("d_$today", p.getLong("d_$today", 0L) + ms)
        e.apply()
    }

    fun streak(c: Context): Int {
        val limit = dailyLimitMin(c) * 60_000L
        if (limit <= 0) return 0
        val days = daysOn(c)
        val firstStr = sp(c).getString("first", null) ?: today()
        val first = try { LocalDate.parse(firstStr) } catch (_: Exception) { LocalDate.now() }
        var d = LocalDate.now().minusDays(1)
        var n = 0
        while (!d.isBefore(first) && n < 365) {
            if (d.dayOfWeek.value in days) {
                if (dayMaxApp(c, d) <= limit) n++ else break
            }
            d = d.minusDays(1)
        }
        return n
    }

    // ---------- checklists and scores ----------
    fun checklist(c: Context, pkg: String): List<String> {
        val s = sp(c).getString("cl_$pkg", null) ?: return DEFAULT_CHECKLIST
        return s.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun setChecklist(c: Context, pkg: String, items: List<String>) {
        val clean = items.map { it.replace("\n", " ").trim() }.filter { it.isNotEmpty() }.distinct()
        sp(c).edit().putString("cl_$pkg", clean.joinToString("\n")).apply()
    }

    fun checkedOn(c: Context, d: LocalDate, pkg: String): Set<String> =
        (sp(c).getString("ck_${d}_$pkg", null) ?: "").split("\n").filter { it.isNotBlank() }.toSet()

    // Score from 1 to 100 (0 when the app has no checklist items)
    fun score(c: Context, pkg: String, done: Set<String> = checkedOn(c, LocalDate.now(), pkg)): Int {
        val entries = checklist(c, pkg)
        if (entries.isEmpty()) return 0
        val n = entries.count { it in done }
        return maxOf(1, 100 * n / entries.size)
    }

    fun setChecked(c: Context, pkg: String, done: Set<String>) {
        val today = today()
        val s = score(c, pkg, done)
        sp(c).edit()
            .putString("ck_${today}_$pkg", done.joinToString("\n"))
            .putInt("sc_${today}_$pkg", s)
            .apply()
    }

    fun scoreOn(c: Context, d: LocalDate, pkg: String): Int = sp(c).getInt("sc_${d}_$pkg", 0)

    fun shownToday(c: Context, pkg: String) = sp(c).getString("shown_$pkg", "") == today()
    fun setShown(c: Context, pkg: String) = sp(c).edit().putString("shown_$pkg", today()).apply()

    fun avgScore(c: Context, pkgs: Collection<String>, from: LocalDate, to: LocalDate): Int? {
        var sum = 0
        var n = 0
        var d = from
        while (!d.isAfter(to)) {
            for (p in pkgs) {
                val s = scoreOn(c, d, p)
                if (s > 0) { sum += s; n++ }
            }
            d = d.plusDays(1)
        }
        return if (n == 0) null else sum / n
    }

    // ---------- journal ----------
    fun journalEntry(c: Context, d: LocalDate): JournalEntry? {
        val s = sp(c).getString("j_$d", null) ?: return null
        return try {
            val o = JSONObject(s)
            val pa = o.optJSONArray("photos")
            val photos = if (pa == null) emptyList() else (0 until pa.length()).map { pa.getString(it) }
            JournalEntry(o.optInt("mood", 3), o.optInt("plan", 1), o.optString("note", ""), o.optInt("acted", -1), photos)
        } catch (_: Exception) { null }
    }

    fun saveJournal(c: Context, d: LocalDate, e: JournalEntry) {
        val s = JSONObject().put("mood", e.mood).put("plan", e.plan).put("note", e.note).put("acted", e.acted).put("photos", JSONArray(e.photos)).toString()
        sp(c).edit().putString("j_$d", s).apply()
    }

    fun allJournal(c: Context): List<Pair<LocalDate, JournalEntry>> {
        val out = ArrayList<Pair<LocalDate, JournalEntry>>()
        for (k in sp(c).all.keys) {
            if (!k.startsWith("j_")) continue
            val d = try { LocalDate.parse(k.substring(2)) } catch (_: Exception) { continue }
            val e = journalEntry(c, d) ?: continue
            out.add(d to e)
        }
        return out.sortedByDescending { it.first }
    }

    fun avgPlan(c: Context, from: LocalDate, to: LocalDate): Int? {
        var sum = 0
        var n = 0
        var d = from
        while (!d.isAfter(to)) {
            journalEntry(c, d)?.let { sum += it.plan * 50; n++ }
            d = d.plusDays(1)
        }
        return if (n == 0) null else sum / n
    }

    // ---------- P&L and evals ----------
    fun rawAll(c: Context): Map<String, *> = sp(c).all

    // generic settings
    fun int(c: Context, key: String, def: Int): Int = sp(c).getInt(key, def)
    fun putInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
    fun bool(c: Context, key: String, def: Boolean): Boolean = sp(c).getBoolean(key, def)
    fun putBool(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()
    fun str(c: Context, key: String, def: String): String = sp(c).getString(key, def) ?: def
    fun putStr(c: Context, key: String, v: String) = sp(c).edit().putString(key, v).apply()

    fun waterGoal(c: Context) = int(c, "water_goal", 8)
    fun waterEveryMin(c: Context) = int(c, "water_every", 60)
    fun lemonHour(c: Context) = int(c, "lemon_hour", 10)
    fun stepGoal(c: Context) = int(c, "step_goal", 8000)
    fun breakAfterMin(c: Context) = int(c, "break_after", 60)
    fun waitAfterMin(c: Context) = int(c, "wait_after", 30)
    fun profitTarget(c: Context) = int(c, "profit_target", 100)
    fun soundOn(c: Context) = bool(c, "sound", true)
    fun lastTier(c: Context) = int(c, "last_tier", -1)

    // ---------- trades (several per day, each with a timestamp) ----------
    fun trades(c: Context, d: LocalDate): List<Trade> {
        val s = sp(c).getString("trades_$d", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Trade(o.optLong("t"), o.optDouble("a", 0.0), o.optString("n", ""))
            }.sortedBy { it.time }
        } catch (_: Exception) { emptyList() }
    }

    private fun saveTrades(c: Context, d: LocalDate, list: List<Trade>) {
        val a = JSONArray()
        list.sortedBy { it.time }.forEach {
            a.put(JSONObject().put("t", it.time).put("a", it.amount).put("n", it.note))
        }
        val e = sp(c).edit()
        if (list.isEmpty()) e.remove("trades_$d") else e.putString("trades_$d", a.toString())
        e.apply()
    }

    fun addTrade(c: Context, d: LocalDate, t: Trade) {
        val list = trades(c, d)
        var time = t.time
        while (list.any { it.time == time }) time++
        saveTrades(c, d, list + t.copy(time = time))
    }

    fun deleteTrade(c: Context, d: LocalDate, time: Long) =
        saveTrades(c, d, trades(c, d).filter { it.time != time })

    fun lastTradeTime(c: Context): Long = trades(c, LocalDate.now()).maxOfOrNull { it.time } ?: 0L

    // a day-total entered before multi-trade logging existed
    fun legacyPnl(c: Context, d: LocalDate): Double? = sp(c).getString("pnl_$d", null)?.toDoubleOrNull()

    // day total = old day-total (if any) + all timestamped trades
    fun pnl(c: Context, d: LocalDate): Double? {
        val legacy = legacyPnl(c, d)
        val t = trades(c, d)
        if (legacy == null && t.isEmpty()) return null
        return (legacy ?: 0.0) + t.sumOf { it.amount }
    }

    // ---------- health ----------
    fun water(c: Context, d: LocalDate): Int = sp(c).getInt("water_$d", 0)
    fun waterLast(c: Context): Long = sp(c).getLong("water_last", 0L)
    fun addWater(c: Context, d: LocalDate, delta: Int) {
        val v = (water(c, d) + delta).coerceAtLeast(0)
        val e = sp(c).edit().putInt("water_$d", v)
        if (delta > 0) e.putLong("water_last", System.currentTimeMillis())
        e.apply()
    }

    fun lemon(c: Context, d: LocalDate): Int = sp(c).getInt("lemon_$d", 0)
    fun addLemon(c: Context, d: LocalDate, delta: Int) =
        sp(c).edit().putInt("lemon_$d", (lemon(c, d) + delta).coerceAtLeast(0)).apply()
    fun lemonRemindedDay(c: Context): String = sp(c).getString("lemon_rem", "") ?: ""
    fun setLemonReminded(c: Context) = sp(c).edit().putString("lemon_rem", today()).apply()

    fun stepsOn(c: Context, d: LocalDate): Int = sp(c).getInt("steps_$d", 0)

    // The step sensor counts since the phone booted, so we keep a baseline for each day
    fun onStepReading(c: Context, v: Long) {
        val p = sp(c)
        val today = today()
        val lastDay = p.getString("step_last_day", null)
        val last = p.getLong("step_last", -1L)
        val e = p.edit()
        var base = p.getLong("stepbase_$today", -1L)
        if (base < 0) {
            base = if (lastDay != null && last >= 0 && v >= last) last else v
            e.putLong("stepbase_$today", base)
        }
        if (v < base) {
            base = 0L
            e.putLong("stepbase_$today", 0L)
        }
        e.putInt("steps_$today", (v - base).toInt().coerceAtLeast(0))
        e.putLong("step_last", v)
        e.putString("step_last_day", today)
        e.apply()
    }

    fun weightKg(c: Context, d: LocalDate): Double? = sp(c).getString("weight_$d", null)?.toDoubleOrNull()
    fun setWeightKg(c: Context, d: LocalDate, kg: Double?) {
        val e = sp(c).edit()
        if (kg == null) e.remove("weight_$d") else e.putString("weight_$d", kg.toString())
        e.apply()
    }
    fun weightHistory(c: Context, days: Int): List<Pair<LocalDate, Double>> {
        val out = ArrayList<Pair<LocalDate, Double>>()
        val now = LocalDate.now()
        for (i in days - 1 downTo 0) {
            val d = now.minusDays(i.toLong())
            val w = weightKg(c, d)
            if (w != null) out.add(d to w)
        }
        return out
    }

    fun setPnl(c: Context, d: LocalDate, v: Double?) {
        val e = sp(c).edit()
        if (v == null) e.remove("pnl_$d") else e.putString("pnl_$d", v.toString())
        e.apply()
    }

    fun currency(c: Context): String = sp(c).getString("currency", "$") ?: "$"
    fun setCurrency(c: Context, s: String) = sp(c).edit().putString("currency", s).apply()

    fun evals(c: Context): List<EvalItem> {
        val s = sp(c).getString("evals", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                EvalItem(o.optLong("id"), o.optString("name"), o.optInt("status"), o.optString("date"))
            }
        } catch (_: Exception) { emptyList() }
    }

    fun saveEvals(c: Context, list: List<EvalItem>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("status", it.status).put("date", it.date))
        }
        sp(c).edit().putString("evals", a.toString()).apply()
    }

    fun monthStats(c: Context, ym: YearMonth): MonthStats {
        var total = 0.0
        var w = 0
        var l = 0
        var f = 0
        var best: Pair<LocalDate, Double>? = null
        var worst: Pair<LocalDate, Double>? = null
        for (day in 1..ym.lengthOfMonth()) {
            val d = ym.atDay(day)
            val p = pnl(c, d) ?: continue
            total += p
            when {
                p > 0 -> w++
                p < 0 -> l++
                else -> f++
            }
            if (best == null || p > best.second) best = d to p
            if (worst == null || p < worst.second) worst = d to p
        }
        return MonthStats(total, w, l, f, best, worst)
    }

    fun journalNotified(c: Context) = sp(c).getString("jn_day", "") == today()
    fun setJournalNotified(c: Context) = sp(c).edit().putString("jn_day", today()).apply()
}

fun fmtClock(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

fun fmtLong(ms: Long): String {
    val m = ms / 60000
    return when {
        m >= 60 -> "${m / 60}h ${m % 60}m"
        m >= 1 -> "${m}m"
        else -> "${ms / 1000}s"
    }
}

fun fmtShort(ms: Long): String {
    val m = ms / 60000
    if (m < 60) return "${m}m"
    val r = "%02d".format(m % 60)
    return "${m / 60}h$r"
}

fun fmtMoney(v: Double, sym: String): String {
    val sign = if (v < 0) "-" else if (v > 0) "+" else ""
    return sign + sym + String.format(Locale.US, "%,.2f", abs(v))
}

fun fmtCompact(v: Double): String {
    val a = abs(v)
    val body = if (a >= 1000) String.format(Locale.US, "%.1fk", a / 1000) else String.format(Locale.US, "%.0f", a)
    return (if (v < 0) "-" else if (v > 0) "+" else "") + body
}

fun moodFor(ratio: Float): Pair<String, Int> = when {
    ratio < 0.5f -> "😎" to 0xCC2E7D32.toInt()
    ratio < 0.8f -> "🙂" to 0xCC9E9D24.toInt()
    ratio < 1f -> "😬" to 0xCCEF6C00.toInt()
    else -> "😱" to 0xCCC62828.toInt()
}

fun hasUsageAccess(c: Context): Boolean {
    val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    @Suppress("DEPRECATION")
    val mode = if (Build.VERSION.SDK_INT >= 29)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    else
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}
