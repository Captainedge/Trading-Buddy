package com.tradingbuddy.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

// Little sound effects made from sine waves, so no audio files are needed
object Sfx {
    private const val RATE = 22050

    private class Note(val freq: Double, val ms: Int, val decay: Double)

    private fun synth(notes: List<Note>, bright: Boolean): ShortArray {
        val total = notes.sumOf { it.ms } * RATE / 1000
        val out = ShortArray(total)
        var pos = 0
        for (n in notes) {
            val len = n.ms * RATE / 1000
            for (i in 0 until len) {
                val t = i.toDouble() / RATE
                val attack = minOf(1.0, i / (0.004 * RATE))
                val env = attack * exp(-n.decay * t)
                var s = sin(2 * PI * n.freq * t)
                if (bright) s += 0.5 * sin(2 * PI * n.freq * 2 * t) + 0.25 * sin(2 * PI * n.freq * 3 * t)
                val v = (s * env * 9000).toInt().coerceIn(-32000, 32000)
                if (pos + i < out.size) out[pos + i] = v.toShort()
            }
            pos += len
        }
        return out
    }

    private fun play(c: Context, samples: ShortArray) {
        if (!Store.soundOn(c)) return
        Thread {
            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(samples.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(samples, 0, samples.size)
                track.play()
                Thread.sleep(samples.size * 1000L / RATE + 250)
                track.release()
            } catch (_: Exception) { }
        }.start()
    }

    // "ka-ching"
    fun coin(c: Context) = play(c, synth(listOf(Note(1319.0, 90, 14.0), Note(1976.0, 520, 5.0)), true))

    // sad trombone
    fun loss(c: Context) =
        play(c, synth(listOf(Note(311.0, 230, 3.0), Note(277.0, 230, 3.0), Note(233.0, 480, 2.5)), false))

    // power-up arpeggio
    fun levelUp(c: Context) = play(
        c,
        synth(
            listOf(
                Note(523.0, 100, 8.0), Note(659.0, 100, 8.0), Note(784.0, 100, 8.0),
                Note(1047.0, 100, 8.0), Note(1319.0, 650, 4.0)
            ),
            true
        )
    )

    // calm chime
    fun chime(c: Context) = play(c, synth(listOf(Note(528.0, 800, 3.5)), true))
}
