package com.tradingbuddy.app

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt

private val GGREEN = Color(0xFF2E9E4F)
private val GORANGE = Color(0xFFEF6C00)
private val GRED = Color(0xFFC62828)
private val STATUS_LABELS = listOf("⏳ Eval", "✅ Passed", "❌ Failed", "💰 Funded", "💥 Blown")

data class AcctView(val item: EvalItem, val pnl: Double, val earned: Double)

data class GoalState(
    val profile: GoalProfile?,
    val masterPnl: Double,
    val payouts: Double,
    val unpaid: Double,
    val monthsElapsed: Double,
    val equity: Double,
    val progress: Float,
    val requiredRate: Double?,
    val actualRate: Double?,
    val projectedMonths: Int?,
    val accounts: List<AcctView>,
    val propMonthly: Double,
    val remaining: Int,
    val contribution: Double,
    val costs: Double
)

object GoalEngine {
    private fun parseDate(s: String): LocalDate? = try { LocalDate.parse(s) } catch (_: Exception) { null }

    // future value after n months of growth r with a monthly contribution cm
    fun fv(e: Double, cm: Double, r: Double, n: Int): Double {
        if (n <= 0) return e
        val g = (1 + r).pow(n)
        val ann = if (abs(r) < 1e-9) n.toDouble() else (g - 1) / r
        return e * g + (if (cm == 0.0) 0.0 else cm * ann)
    }

    // monthly growth needed to reach the target, or null if it is over 300% a month
    fun requiredRate(e: Double, cm: Double, t: Double, n: Int): Double? {
        val base = maxOf(e, 1.0)
        if (fv(base, cm, 0.0, n) >= t) return 0.0
        if (fv(base, cm, 3.0, n) < t) return null
        var lo = 0.0
        var hi = 3.0
        repeat(60) {
            val mid = (lo + hi) / 2
            if (fv(base, cm, mid, n) >= t) hi = mid else lo = mid
        }
        return hi
    }

    private fun monthsToTarget(e: Double, cm: Double, r: Double, t: Double): Int? {
        if (r <= -1.0) return null
        var eq = maxOf(e, 0.0)
        for (m in 1..600) {
            eq = eq * (1 + r) + cm
            if (eq >= t) return m
        }
        return null
    }

    fun compute(c: Context): GoalState {
        val p = Store.goalProfile(c)
        val today = LocalDate.now()
        val evals = Store.evals(c)
        val startDate = p?.let { parseDate(it.start) } ?: today
        var earliest = startDate
        for (e in evals) {
            if (e.mirror) parseDate(e.date)?.let { if (it.isBefore(earliest)) earliest = it }
        }
        if (ChronoUnit.DAYS.between(earliest, today) > 1500) earliest = today.minusDays(1500)
        val dayPnl = HashMap<LocalDate, Double>()
        var d = earliest
        while (!d.isAfter(today)) {
            val v = Store.pnl(c, d)
            if (v != null) dayPnl[d] = v
            d = d.plusDays(1)
        }
        fun sumBetween(from: LocalDate, to: LocalDate): Double {
            var s = 0.0
            for ((k, v) in dayPnl) if (!k.isBefore(from) && !k.isAfter(to)) s += v
            return s
        }

        val masterPnl = if (p != null) sumBetween(startDate, today) else 0.0
        val views = evals.map { e ->
            val st = parseDate(e.date) ?: today
            val en = parseDate(e.end) ?: today
            val copied = if (e.mirror) e.factor * sumBetween(st, en) else 0.0
            val pnl = e.adjust + copied
            val earned = if (e.status == 3) maxOf(0.0, pnl) * e.split / 100.0 else 0.0
            AcctView(e, pnl, earned)
        }
        val payouts = evals.sumOf { it.payouts }
        val costs = evals.sumOf { it.cost }
        val unpaid = views.sumOf { maxOf(0.0, it.earned - it.item.payouts) }
        val monthsElapsed = if (p != null) ChronoUnit.DAYS.between(startDate, today) / 30.44 else 0.0

        var propMonthly = 0.0
        for (v in views) {
            if (v.item.status == 3) {
                val st = parseDate(v.item.date) ?: today
                val months = maxOf(1.0, ChronoUnit.DAYS.between(st, today) / 30.44)
                propMonthly += v.earned / months
            }
        }

        val capital = p?.capital ?: 0.0
        val savingsAdded = (p?.savings ?: 0.0) * monthsElapsed
        val equity = capital + masterPnl + payouts - costs + savingsAdded
        val cm = (p?.savings ?: 0.0) + propMonthly
        val remaining = if (p != null) maxOf(1, p.months - monthsElapsed.toInt()) else 1

        val actual: Double? = if (p != null && monthsElapsed >= 0.25) {
            val base = maxOf(1.0, capital + masterPnl)
            (masterPnl / maxOf(1.0, monthsElapsed)) / base
        } else null
        val required = if (p != null) requiredRate(equity, cm, p.target, remaining) else null
        val projected = if (p != null && actual != null) monthsToTarget(equity, cm, actual, p.target) else null
        val progress = if (p != null && p.target > 0) (equity / p.target).toFloat().coerceIn(0f, 1f) else 0f
        return GoalState(
            p, masterPnl, payouts, unpaid, monthsElapsed, equity, progress,
            required, actual, projected, views, propMonthly, remaining, cm, costs
        )
    }
}

private fun numStr(v: Double?): String =
    if (v == null) "" else if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

private fun realism(r: Double?): Pair<String, Color> = when {
    r == null -> "Practically impossible (over 300% a month)" to GRED
    r <= 0.0 -> "On track from your savings and payouts alone" to GGREEN
    r <= 0.01 -> "Realistic" to GGREEN
    r <= 0.03 -> "Ambitious but possible" to GORANGE
    r <= 0.08 -> "Aggressive" to GORANGE
    r <= 0.20 -> "Extreme: very few traders can sustain this" to GRED
    else -> "Practically impossible without huge risk" to GRED
}

private fun expHint(y: Double): String = when {
    y < 1 -> "Under a year in: most traders lose money in this phase, so protect your capital and log every trade."
    y < 3 -> "1 to 3 years in: consistency matters most now. Your journal data is your edge."
    else -> "3+ years in: you know your edge. Scale size slowly and keep the rules."
}

private fun pct(r: Double): String = String.format(Locale.US, "%.1f%%", r * 100)

private fun span(months: Int): String {
    val y = months / 12
    val m = months % 12
    return if (y > 0) "$y y $m m" else "$m months"
}

@Composable
private fun NumField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { v -> onChange(v.filter { it.isDigit() || it == '.' }) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun GoalsTab(tick: Int) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    val sym = remember(rev) { Store.currency(ctx) }
    val profile = remember(rev) { Store.goalProfile(ctx) }
    val gs by produceState<GoalState?>(null, rev, tick / 3) {
        value = withContext(Dispatchers.Default) { GoalEngine.compute(ctx) }
    }
    val g = gs
    var capital by remember(profile) { mutableStateOf(numStr(profile?.capital)) }
    var income by remember(profile) { mutableStateOf(numStr(profile?.income)) }
    var savings by remember(profile) { mutableStateOf(numStr(profile?.savings)) }
    var exp by remember(profile) { mutableStateOf(numStr(profile?.expYears)) }
    var target by remember(profile) { mutableStateOf(numStr(profile?.target ?: 1_000_000.0)) }
    var months by remember(profile) { mutableStateOf(numStr((profile?.months ?: 24).toDouble())) }
    var newName by remember { mutableStateOf("") }
    var newSize by remember { mutableStateOf("") }
    var newMirror by remember { mutableStateOf(true) }
    var newCost by remember { mutableStateOf("") }

    val update: (Long, (EvalItem) -> EvalItem) -> Unit = { id, f ->
        Store.saveEvals(ctx, Store.evals(ctx).map { if (it.id == id) f(it) else it })
        rev++
    }

    TabList {
        item {
            Text("Goals 🎯", style = MaterialTheme.typography.headlineMedium)
            Text("Set a target, see what it really takes, and track your copy-trade prop accounts.")
        }

        // ---- profile ----
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("My numbers", style = MaterialTheme.typography.titleMedium)
                    NumField("Starting capital ($sym)", capital) { capital = it }
                    NumField("Monthly income ($sym)", income) { income = it }
                    NumField("Monthly amount you can add to your account ($sym)", savings) { savings = it }
                    NumField("Trading experience (years)", exp) { exp = it }
                    NumField("Goal amount ($sym)", target) { target = it }
                    NumField("Goal timeframe (months)", months) { months = it }
                    Button(
                        onClick = {
                            Store.saveGoalProfile(
                                ctx,
                                GoalProfile(
                                    capital.toDoubleOrNull() ?: 0.0,
                                    income.toDoubleOrNull() ?: 0.0,
                                    savings.toDoubleOrNull() ?: 0.0,
                                    exp.toDoubleOrNull() ?: 0.0,
                                    maxOf(1.0, target.toDoubleOrNull() ?: 1_000_000.0),
                                    maxOf(1, (months.toDoubleOrNull() ?: 24.0).roundToInt()),
                                    profile?.start ?: LocalDate.now().toString()
                                )
                            )
                            rev++
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (profile == null) "Save my goal" else "Update") }
                    if (profile != null) {
                        Text("Goal clock started ${profile.start}", style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = {
                            Store.saveGoalProfile(ctx, profile.copy(start = LocalDate.now().toString()))
                            rev++
                        }) { Text("Restart the goal clock from today") }
                    }
                }
            }
        }

        // ---- progress and reality check ----
        if (profile != null && g != null) {
            val (label, labelColor) = realism(g.requiredRate)
            val deadline = runCatching { LocalDate.parse(profile.start).plusMonths(profile.months.toLong()) }
                .getOrDefault(LocalDate.now())
            val daysLeft = ChronoUnit.DAYS.between(LocalDate.now(), deadline)
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "${fmtPlain(profile.target, sym)} goal · ${if (daysLeft >= 0) "$daysLeft days left" else "deadline passed"}",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            fmtPlain(g.equity, sym),
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (g.equity >= profile.capital) GGREEN else GRED
                        )
                        LinearProgressIndicator(progress = { g.progress }, modifier = Modifier.fillMaxWidth())
                        Text(
                            "${String.format(Locale.US, "%.2f", g.progress * 100)}% of the way",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("Starting capital ${fmtPlain(profile.capital, sym)}", style = MaterialTheme.typography.bodySmall)
                        Text("Trading P&L since start ${fmtMoney(g.masterPnl, sym)}", style = MaterialTheme.typography.bodySmall)
                        Text("Prop payouts received ${fmtPlain(g.payouts, sym)}", style = MaterialTheme.typography.bodySmall)
                        Text("Prop fees paid -${fmtPlain(g.costs, sym)}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            "Savings added ${fmtPlain(profile.savings * g.monthsElapsed, sym)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (g.unpaid > 0) {
                            Text(
                                "Unpaid prop earnings (estimate) ${fmtPlain(g.unpaid, sym)}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Reality check 🧮", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (g.requiredRate == null) "To hit the goal in time you'd need over 300% every month."
                            else "To hit the goal in ${g.remaining} months you'd need about ${pct(g.requiredRate)} a month, every month.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(label, color = labelColor, fontWeight = FontWeight.Bold)
                        Text(
                            if (g.actualRate == null) "Log about a week of trades to see your real pace."
                            else "Your pace so far: ${pct(g.actualRate)} a month.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        if (g.actualRate != null) {
                            Text(
                                if (g.projectedMonths == null) "At this pace the goal isn't reached within 50 years."
                                else "At this pace you'd reach it in ${span(g.projectedMonths)}.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        if (g.propMonthly > 0) {
                            Text(
                                "Prop accounts are adding about ${fmtPlain(g.propMonthly, sym)} a month.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Text(expHint(profile.expYears), style = MaterialTheme.typography.bodySmall)
                        Text(
                            "Estimates only. Past results don't guarantee future ones, and this isn't financial advice.",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("What-if: ${g.remaining} months from now", style = MaterialTheme.typography.titleMedium)
                        listOf(0.0, 0.02, 0.05, 0.10, 0.20).forEach { r ->
                            val v = GoalEngine.fv(maxOf(g.equity, 0.0), g.contribution, r, g.remaining)
                            Row {
                                Text("${pct(r)} a month", Modifier.weight(1f))
                                Text(
                                    fmtPlain(v, sym),
                                    fontWeight = FontWeight.Bold,
                                    color = if (v >= profile.target) GGREEN else Color.Unspecified
                                )
                            }
                        }
                        Text(
                            "Includes your monthly savings and prop payout pace.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        // ---- prop firm accounts ----
        item {
            val accts = g?.accounts ?: emptyList()
            val live = accts.filter { it.item.status != 2 && it.item.status != 4 }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Prop firm accounts 🏦", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${live.size} live · buying power ${fmtPlain(live.sumOf { it.item.size }, sym)} · " +
                            "copy P&L ${fmtMoney(accts.filter { it.item.mirror }.sumOf { it.pnl }, sym)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "💰 ${accts.count { it.item.status == 3 }} funded · ✅ ${accts.count { it.item.status == 1 }} passed · " +
                            "❌ ${accts.count { it.item.status == 2 }} failed · 💥 ${accts.count { it.item.status == 4 }} blown",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "Fees paid ${fmtPlain(accts.sumOf { it.item.cost }, sym)} · payouts ${fmtPlain(accts.sumOf { it.item.payouts }, sym)} · net ${fmtMoney(accts.sumOf { it.item.payouts - it.item.cost }, sym)}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                    accts.forEach { v ->
                        key(v.item.id) {
                            AccountRow(v, sym, update) { id ->
                                Store.saveEvals(ctx, Store.evals(ctx).filter { it.id != id })
                                rev++
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("Add an account", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Name (e.g. Apex 50K #3)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    NumField("Account size ($sym)", newSize) { newSize = it }
                    NumField("Cost / eval fee ($sym)", newCost) { newCost = it }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Copy my trades to it", Modifier.weight(1f))
                        Switch(checked = newMirror, onCheckedChange = { newMirror = it })
                    }
                    Button(
                        onClick = {
                            val n = newName.trim()
                            if (n.isNotEmpty()) {
                                Store.saveEvals(
                                    ctx,
                                    Store.evals(ctx) + EvalItem(
                                        System.currentTimeMillis(), n, 0, LocalDate.now().toString(),
                                        size = newSize.toDoubleOrNull() ?: 0.0, mirror = newMirror,
                                        cost = newCost.toDoubleOrNull() ?: 0.0
                                    )
                                )
                                newName = ""
                                newSize = ""
                                newCost = ""
                                rev++
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Add account") }
                    Text(
                        "Copied accounts follow every trade you log from their start date, multiplied by the copy size. Edit or delete a trade and they update.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun AccountRow(
    v: AcctView,
    sym: String,
    update: (Long, (EvalItem) -> EvalItem) -> Unit,
    onDelete: (Long) -> Unit
) {
    val e = v.item
    var open by remember(e.id) { mutableStateOf(false) }
    var payText by remember(e.id) { mutableStateOf("") }
    var costText by remember(e.id) { mutableStateOf("") }
    Card(
        Modifier.fillMaxWidth().clickable { open = !open },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(e.name, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text(STATUS_LABELS[e.status.coerceIn(0, 4)], style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.width(8.dp))
                Text(if (open) "▲" else "▼")
            }
            Text(
                "${fmtPlain(e.size, sym)} · P&L ${fmtMoney(v.pnl, sym)}" +
                    (if (e.mirror) " (copy ×${String.format(Locale.US, "%.1f", e.factor)})" else "") +
                    (if (e.payouts > 0) " · paid ${fmtPlain(e.payouts, sym)}" else "") +
                    (if (e.cost > 0) " · fee ${fmtPlain(e.cost, sym)}" else ""),
                style = MaterialTheme.typography.bodySmall
            )
            if (open) {
                STATUS_LABELS.indices.chunked(3).forEach { rowIdx ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        rowIdx.forEach { i ->
                            val label = STATUS_LABELS[i]
                            val set: () -> Unit = {
                                update(e.id) {
                                    it.copy(
                                        status = i,
                                        end = if (i == 2 || i == 4) LocalDate.now().toString() else ""
                                    )
                                }
                            }
                            if (e.status == i) Button(
                                onClick = set,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(0.dp)
                            ) { Text(label, fontSize = 11.sp, maxLines = 1) }
                            else OutlinedButton(
                                onClick = set,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(0.dp)
                            ) { Text(label, fontSize = 11.sp, maxLines = 1) }
                        }
                        repeat(3 - rowIdx.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Copy my trades to this account", Modifier.weight(1f))
                    Switch(checked = e.mirror, onCheckedChange = { on -> update(e.id) { it.copy(mirror = on) } })
                }
                if (e.mirror) {
                    Stepper(
                        "Copy size", (e.factor * 10).roundToInt(), 5, 50,
                        { "×" + String.format(Locale.US, "%.1f", it / 10.0) }
                    ) { n -> update(e.id) { it.copy(factor = n / 10.0) } }
                }
                Stepper("Profit split", e.split, 5, 100, { "$it%" }) { n -> update(e.id) { it.copy(split = n) } }
                if (e.status == 3) {
                    Text(
                        "Earned so far ${fmtPlain(v.earned, sym)} · unpaid ${fmtPlain(maxOf(0.0, v.earned - e.payouts), sym)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = payText,
                        onValueChange = { t -> payText = t.filter { it.isDigit() || it == '.' } },
                        label = { Text("Payout received ($sym)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val amt = payText.toDoubleOrNull()
                        if (amt != null && amt > 0) {
                            update(e.id) { it.copy(payouts = it.payouts + amt) }
                            payText = ""
                        }
                    }) { Text("Log") }
                }
                Text(
                    "Fees paid ${fmtPlain(e.cost, sym)} · payouts ${fmtPlain(e.payouts, sym)} · net ${fmtMoney(e.payouts - e.cost, sym)}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = costText,
                        onValueChange = { t -> costText = t.filter { it.isDigit() || it == '.' } },
                        label = { Text("Add fee / cost ($sym)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val amt = costText.toDoubleOrNull()
                        if (amt != null && amt > 0) {
                            update(e.id) { it.copy(cost = it.cost + amt) }
                            costText = ""
                        }
                    }) { Text("Add") }
                }
                if (e.cost > 0) {
                    TextButton(onClick = { update(e.id) { it.copy(cost = 0.0) } }) { Text("Clear fees (fix a mistake)") }
                }
                TextButton(onClick = { onDelete(e.id) }) { Text("🗑 Delete this account") }
            }
        }
    }
}
