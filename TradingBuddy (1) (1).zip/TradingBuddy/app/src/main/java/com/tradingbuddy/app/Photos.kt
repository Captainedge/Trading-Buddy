package com.tradingbuddy.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate

// Journal photos are copied (and shrunk) into the app's private storage
object Photos {
    private fun dir(c: Context): File = File(c.filesDir, "journal").apply { mkdirs() }
    fun file(c: Context, name: String) = File(dir(c), name)

    fun delete(c: Context, name: String) {
        try { file(c, name).delete() } catch (_: Exception) { }
    }

    fun save(c: Context, date: LocalDate, uri: Uri): String? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val big = maxOf(bounds.outWidth, bounds.outHeight)
            while (big / sample > 2000) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null
            val rot = try {
                c.contentResolver.openInputStream(uri)?.use { s ->
                    when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (_: Exception) { 0f }
            if (rot != 0f) {
                val m = Matrix().apply { postRotate(rot) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val name = "${date}_${System.currentTimeMillis()}_${(1000..9999).random()}.jpg"
            FileOutputStream(file(c, name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            name
        } catch (_: Exception) { null }
    }

    fun bitmap(c: Context, name: String, maxDim: Int): Bitmap? {
        return try {
            val f = file(c, name)
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, b)
            var sample = 1
            val big = maxOf(b.outWidth, b.outHeight)
            while (big / (sample * 2) >= maxDim) sample *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (_: Exception) { null }
    }

    fun base64(c: Context, name: String, maxDim: Int): String? {
        val bmp = bitmap(c, name, maxDim) ?: return null
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 75, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
