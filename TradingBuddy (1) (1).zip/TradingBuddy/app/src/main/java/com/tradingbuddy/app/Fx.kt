package com.tradingbuddy.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

// Emojis fall from the top of the screen each time `trigger` changes
@Composable
fun EmojiRain(trigger: Int, emojis: List<String>) {
    if (trigger == 0) return
    key(trigger) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val w = constraints.maxWidth.toFloat()
            val h = constraints.maxHeight.toFloat()
            repeat(26) { i ->
                val prog = remember { Animatable(0f) }
                val xf = remember { Random.nextFloat() }
                val wait = remember { Random.nextInt(0, 700) }
                val dur = remember { 1400 + Random.nextInt(0, 1300) }
                val e = remember { emojis.random() }
                LaunchedEffect(Unit) {
                    delay(wait.toLong())
                    prog.animateTo(1f, tween(dur, easing = LinearEasing))
                }
                if (prog.value > 0f && prog.value < 1f) {
                    Text(
                        e,
                        fontSize = (20 + (i % 3) * 8).sp,
                        modifier = Modifier.graphicsLayer {
                            translationX = xf * (w - 80f)
                            translationY = -100f + prog.value * (h + 200f)
                            rotationZ = prog.value * (if (i % 2 == 0) 360f else -360f)
                        }
                    )
                }
            }
        }
    }
}
