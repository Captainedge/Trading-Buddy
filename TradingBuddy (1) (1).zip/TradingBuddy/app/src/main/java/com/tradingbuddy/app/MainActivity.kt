package com.tradingbuddy.app

import android.Manifest
import android.widget.Toast
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate

data class AppInfo(val pkg: String, val label: String)

class MainActivity : ComponentActivity() {
    private var resumes by mutableIntStateOf(0)
    private var requestedTab by mutableIntStateOf(-1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestedTab = intent.getIntExtra("tab", -1)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { TradingBuddyScreen(resumes, requestedTab) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        requestedTab = intent.getIntExtra("tab", -1)
    }

    override fun onResume() {
        super.onResume()
        resumes++
    }
}

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun TradingBuddyScreen(resumes: Int, requestedTab: Int) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    var tracked by remember { mutableStateOf(Store.tracked(ctx)) }
    var tick by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(TrackerService.running) }
    var rain by remember { mutableIntStateOf(0) }
    var rainEmojis by remember { mutableStateOf(listOf("💰")) }
    val fx: (List<String>) -> Unit = { e ->
        rainEmojis = e
        rain++
    }

    LaunchedEffect(requestedTab) { if (requestedTab >= 0) tab = requestedTab }
    LaunchedEffect(Unit) {
        Store.touch(ctx)
        apps = withContext(Dispatchers.Default) { loadApps(ctx) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            tick++
            running = TrackerService.running
        }
    }
    BackHandler(enabled = tab == 5) { tab = 0 }

    val labelMap = remember(apps) { apps.associate { it.pkg to it.label } }
    val tabs = listOf("🏠" to "Home", "✅" to "Checks", "📊" to "Tracker", "📓" to "Journal", "❤️" to "Health")

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { i, (emoji, name) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(emoji) },
                            label = { Text(name, maxLines = 1) }
                        )
                    }
                }
            }
        ) { inner ->
            Box(Modifier.padding(inner).fillMaxSize()) {
                when (tab) {
                    0 -> HomeTab(resumes, tick, running, { running = it }, tracked, labelMap, fx) { tab = 5 }
                    1 -> ChecklistTab(tick, tracked, labelMap) { tab = 5 }
                    2 -> TrackerHost(tick, tracked, labelMap)
                    3 -> JournalHost(tick, tracked)
                    4 -> HealthTab(tick, fx)
                    else -> SettingsTab(tick, apps, tracked, { tab = 0 }) {
                        tracked = it
                        Store.setTracked(ctx, it)
                    }
                }
            }
        }
        EmojiRain(rain, rainEmojis)
    }
}

@Composable
fun HomeTab(
    resumes: Int,
    tick: Int,
    running: Boolean,
    setRunning: (Boolean) -> Unit,
    tracked: Set<String>,
    labelMap: Map<String, String>,
    fx: (List<String>) -> Unit,
    goSettings: () -> Unit
) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    val usageOk = remember(resumes, tick) { hasUsageAccess(ctx) }
    val overlayOk = remember(resumes, tick) { Settings.canDrawOverlays(ctx) }
    val limit = remember(tick) { Store.dailyLimitMin(ctx) }
    val sym = remember(tick, rev) { Store.currency(ctx) }
    // the XP maths scans the saved data, so it runs in the background
    val gameState by produceState<GameState?>(null, rev, tick / 3) {
        value = withContext(Dispatchers.Default) { Game.compute(ctx) }
    }
    val game = gameState ?: GameState(0, 0, 0f, TIERS[1].minXp, DayPoints(0, 0, 0, 0))
    val tierNow = gameState?.tier
    val today = LocalDate.now()
    val trades = remember(tick, rev) { Store.trades(ctx, today) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    // level up celebration
    LaunchedEffect(tierNow) {
        val t = tierNow ?: return@LaunchedEffect
        val last = Store.lastTier(ctx)
        if (last >= 0 && t > last) {
            Sfx.levelUp(ctx)
            fx(listOf("⚡", "🔥", "✨", "🌟"))
            Toast.makeText(ctx, "LEVEL UP! ${TIERS[t].emoji} ${TIERS[t].name}", Toast.LENGTH_LONG).show()
        }
        if (last != t) Store.putInt(ctx, "last_tier", t)
    }

    TabList {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Trading Buddy 📈", style = MaterialTheme.typography.headlineMedium)
                    Text("Level up your discipline.")
                }
                TextButton(onClick = goSettings) { Text("⚙️ Settings") }
            }
        }
        item { HeroCard(game) }
        item {
            TradeLoggerCard(sym) { amt ->
                if (amt > 0) {
                    Sfx.coin(ctx)
                    fx(listOf("💰", "🤑", "💵", "✨"))
                } else {
                    Sfx.loss(ctx)
                    fx(listOf("💸", "😬"))
                }
                rev++
            }
        }
        item {
            TodayTradesCard(trades, sym) { time ->
                Store.deleteTrade(ctx, today, time)
                rev++
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    PermRow("Usage access", usageOk) {
                        ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    }
                    PermRow("Display over other apps", overlayOk) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        )
                    }
                    PermRow("Unrestricted battery (recommended)", null) {
                        ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                }
            }
        }
        item {
            Button(
                onClick = {
                    val svc = Intent(ctx, TrackerService::class.java)
                    if (running) {
                        ctx.stopService(svc)
                        Store.setEnabled(ctx, false)
                        setRunning(false)
                    } else {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED
                        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        ContextCompat.startForegroundService(ctx, svc)
                        Store.setEnabled(ctx, true)
                        setRunning(true)
                    }
                },
                enabled = usageOk && overlayOk,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (running) "Stop timer" else "Start timer") }
        }
        item { Text("Today's scores", style = MaterialTheme.typography.titleMedium) }
        if (tracked.isEmpty()) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("No apps selected yet.")
                        Button(onClick = goSettings) { Text("Pick apps") }
                    }
                }
            }
        }
        items(tracked.sortedBy { labelMap[it] ?: it }, key = { it }) { pkg ->
            val entries = remember(tick) { Store.checklist(ctx, pkg) }
            val done = remember(tick) { Store.checkedOn(ctx, LocalDate.now(), pkg) }
            val used = remember(tick) { Store.usedToday(ctx, pkg) }
            ScoreCard(
                labelMap[pkg] ?: pkg,
                Store.score(ctx, pkg, done),
                entries.count { it in done },
                entries.size,
                used,
                limit
            )
        }
    }
}

@Composable
fun SettingsTab(tick: Int, apps: List<AppInfo>, tracked: Set<String>, onBack: () -> Unit, onTracked: (Set<String>) -> Unit) {
    val ctx = LocalContext.current
    var dayLimit by remember { mutableIntStateOf(Store.dailyLimitMin(ctx)) }
    var sessLimit by remember { mutableIntStateOf(Store.sessionLimitMin(ctx)) }
    var days by remember { mutableStateOf(Store.daysOn(ctx)) }
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) { apps.filter { it.label.contains(query, ignoreCase = true) } }
    val scheduled = remember(days, tick) { LocalDate.now().dayOfWeek.value in days }

    TabList {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Back") }
                Text("Settings ⚙️", style = MaterialTheme.typography.headlineMedium)
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Limits & alarms", style = MaterialTheme.typography.titleMedium)
                    Stepper("Daily limit (each app)", dayLimit, 15, 600) {
                        dayLimit = it
                        Store.setDailyLimitMin(ctx, it)
                    }
                    Stepper("Session alarm", sessLimit, 5, 120) {
                        sessLimit = it
                        Store.setSessionLimitMin(ctx, it)
                    }
                    Text(
                        "Each app gets its own budget. Passing a limit gives a buzz, a sound and a fun popup. 0 = off.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Schedule 📅", style = MaterialTheme.typography.titleMedium)
                    Text("Trading Buddy only runs on these days:")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("M", "T", "W", "T", "F", "S", "S").forEachIndexed { i, letter ->
                            val dow = i + 1
                            val on = dow in days
                            val flip = {
                                val n = if (on) days - dow else days + dow
                                days = n
                                Store.setDays(ctx, n)
                            }
                            if (on) Button(
                                onClick = flip,
                                modifier = Modifier.weight(1f).height(44.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) { Text(letter) }
                            else OutlinedButton(
                                onClick = flip,
                                modifier = Modifier.weight(1f).height(44.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) { Text(letter) }
                        }
                    }
                    Row {
                        TextButton(onClick = {
                            days = setOf(1, 2, 3, 4, 5); Store.setDays(ctx, days)
                        }) { Text("Weekdays") }
                        TextButton(onClick = {
                            days = setOf(1, 2, 3, 4, 5, 6, 7); Store.setDays(ctx, days)
                        }) { Text("Every day") }
                    }
                    Text(
                        if (scheduled) "Today is a trading-buddy day ✅" else "Today is a rest day 😴",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "Tap Start timer once on the Home tab. After that it runs by itself on your chosen days, even after a restart.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item { WellnessSettings() }
        item {
            var cur by remember { mutableStateOf(Store.currency(ctx)) }
            OutlinedTextField(
                value = cur,
                onValueChange = { cur = it.take(3); Store.setCurrency(ctx, cur) },
                label = { Text("Currency symbol for P&L") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Text("Apps to track", style = MaterialTheme.typography.titleMedium)
            Text("${tracked.size} selected", style = MaterialTheme.typography.bodySmall)
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search apps") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        items(filtered, key = { it.pkg }) { app ->
            val isTracked = app.pkg in tracked
            val icon = rememberAppIcon(app.pkg)
            Row(
                Modifier.fillMaxWidth().clickable {
                    onTracked(if (isTracked) tracked - app.pkg else tracked + app.pkg)
                },
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (icon != null) Image(icon, contentDescription = null, modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Text(app.label, Modifier.weight(1f))
                Checkbox(checked = isTracked, onCheckedChange = null)
            }
        }
    }
}
