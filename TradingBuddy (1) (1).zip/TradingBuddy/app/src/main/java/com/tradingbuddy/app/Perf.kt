package com.tradingbuddy.app

import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

// App icons are decoded once, off the main thread, and cached
private val iconCache = ConcurrentHashMap<String, ImageBitmap>()

@Composable
fun rememberAppIcon(pkg: String): ImageBitmap? {
    val ctx = LocalContext.current
    val state = produceState<ImageBitmap?>(iconCache[pkg], pkg) {
        if (value == null) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
                }.getOrNull()?.also { iconCache[pkg] = it }
            }
        }
    }
    return state.value
}

// Journal photos are decoded in the background too
@Composable
fun rememberPhoto(name: String, maxDim: Int): ImageBitmap? {
    val ctx = LocalContext.current
    val state = produceState<ImageBitmap?>(null, name, maxDim) {
        value = withContext(Dispatchers.IO) { Photos.bitmap(ctx, name, maxDim)?.asImageBitmap() }
    }
    return state.value
}
