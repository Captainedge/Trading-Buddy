package com.tradingbuddy.app

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDate

// Handles the "Drank 💧" and "Drank 🍋" buttons on reminder notifications
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        when (i.getStringExtra("kind")) {
            "water" -> {
                Store.addWater(c, LocalDate.now(), 1)
                nm.cancel(3)
            }
            "lemon" -> {
                Store.addLemon(c, LocalDate.now(), 1)
                nm.cancel(4)
            }
        }
    }
}
