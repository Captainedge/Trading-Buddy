package com.tradingbuddy.app

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.TextStyle as DayStyle
import java.util.Locale
import kotlin.math.ceil

private val SGREEN = Color(0xFF2E9E4F)
private val SRED = Color(0xFFC62828)
private val SGRAY = Color(0xFF9E9E9E)

data class OutcomeStats(
    val n: Int,
    val wins: Int,
    val losses: Int,
    val flat: Int,
    val noPnl: Int,
    val total: Double
) {
    val decided: Int get() = wins + losses + flat
    val winRate: Int? get() = if (decided > 0) wins * 100 / decided else null
}

private val STOP = setOf(
    "the", "and", "for", "that", "this", "with", "was", "were", "are", "have", "has", "had",
    "but", "not", "you", "your", "from", "they", "then", "than", "into", "just", "very", "some",
    "any", "can", "been", "too", "also", "when", "what", "which", "where", "there", "who", "why",
    "how", "all", "out", "did", "does"
)

private fun tokens(s: String): List<String> =
    s.lowercase().replace("'", "").split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 && it !in STOP }

private fun stem(w: String) = if (w.length > 5) w.take(5) else w

// Finds journal entries whose note contains the phrase, or most of its key words
fun searchJournal(
    all: List<Pair<LocalDate, JournalEntry>>,
    query: String
): List<Pair<LocalDate, JournalEntry>> {
    val q = query.trim().lowercase()
    if (q.length < 3) return emptyList()
    val keys = tokens(q).map { stem(it) }.distinct()
    val need = maxOf(1, ceil(keys.size * 0.6).toInt())
    return all.filter { (_, e) ->
        val note = e.note.lowercase()
        if (note.contains(q)) true
        else if (keys.isEmpty()) false
        else {
            val toks = tokens(note).map { stem(it) }.toSet()
            keys.count { it in toks } >= need
        }
    }
}

fun outcomeOf(c: Context, list: List<Pair<LocalDate, JournalEntry>>): OutcomeStats {
    var w = 0
    var l = 0
    var f = 0
    var np = 0
    var total = 0.0
    for ((d, _) in list) {
        val p = Store.pnl(c, d)
        if (p == null) { np++; continue }
        total += p
        when {
            p > 0 -> w++
            p < 0 -> l++
            else -> f++
        }
    }
    return OutcomeStats(list.size, w, l, f, np, total)
}

private fun verdict(acted: OutcomeStats, held: OutcomeStats): String {
    if (acted.decided == 0 && held.decided == 0) {
        return "Not enough P&L yet. Log your P&L and tag whether you acted on the feeling."
    }
    val parts = mutableListOf<String>()
    if (acted.decided > 0) {
        val lossRate = acted.losses * 100 / acted.decided
        parts += when {
            acted.wins > acted.losses ->
                "When you acted on this feeling you won ${acted.winRate}% of the time (${acted.wins} of ${acted.decided})."
            acted.losses > acted.wins ->
                "When you acted on this feeling you lost $lossRate% of the time (${acted.losses} of ${acted.decided})."
            else -> "Acting on this feeling is a coin flip so far (${acted.wins} wins, ${acted.losses} losses)."
        }
    }
    if (held.decided > 0) {
        parts += "When you held back: ${held.wins} win days and ${held.losses} loss days."
    }
    if (acted.decided + held.decided < 5) parts += "Small sample, so treat it as a hint, not a rule."
    return parts.joinToString(" ")
}

private fun dShort(d: LocalDate) =
    d.dayOfWeek.getDisplayName(DayStyle.SHORT, Locale.getDefault()) + " " + d.dayOfMonth + " " +
        d.month.getDisplayName(DayStyle.SHORT, Locale.getDefault())

@Composable
private fun OutcomeBlock(title: String, s: OutcomeStats, sym: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("$title · ${s.n} times", fontWeight = FontWeight.Bold)
        if (s.n == 0) {
            Text("None yet", style = MaterialTheme.typography.bodySmall)
        } else {
            Text(
                "🟢 ${s.wins} wins · 🔴 ${s.losses} losses · ⚪ ${s.flat} flat" +
                    (if (s.noPnl > 0) " · ${s.noPnl} no P&L" else ""),
                style = MaterialTheme.typography.bodySmall
            )
            if (s.decided > 0) {
                Text(
                    "Win rate ${s.winRate ?: 0}% · Net ${fmtMoney(s.total, sym)}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun SearchTab(tick: Int, onEdit: (LocalDate) -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var rev by remember { mutableIntStateOf(0) }
    var editDay by remember { mutableStateOf<LocalDate?>(null) }
    val sym = remember(tick, rev) { Store.currency(ctx) }
    val all = remember(rev) { Store.allJournal(ctx) }
    val matches = remember(query, all) { searchJournal(all, query) }
    val acted = remember(matches, rev) { outcomeOf(ctx, matches.filter { it.second.acted == 1 }) }
    val held = remember(matches, rev) { outcomeOf(ctx, matches.filter { it.second.acted == 0 }) }
    val untagged = matches.count { it.second.acted != 0 && it.second.acted != 1 }
    val moods = listOf("😡", "😕", "😐", "🙂", "🤩")

    val ed = editDay
    if (ed != null) {
        TradesDialog(ed, sym, { editDay = null; rev++ }) { rev++ }
    }

    TabList {
        item {
            Text("Search 🔎", style = MaterialTheme.typography.headlineMedium)
            Text("Type a feeling or phrase. I'll find similar journal entries and show what usually happened.")
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("e.g. seeing the chart both ways") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (query.trim().length < 3) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${all.size} journal entries saved.")
                        Text(
                            "Try: \"FOMO\", \"revenge trade\", \"felt confident\", \"chart both ways\". " +
                                "An entry matches when it uses most of your words.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        } else if (matches.isEmpty()) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) { Text("No similar entries yet. Try fewer or different words.") }
                }
            }
        } else {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "Found ${matches.size} similar ${if (matches.size == 1) "entry" else "entries"}",
                            style = MaterialTheme.typography.titleMedium
                        )
                        OutcomeBlock("Acted on it ✅", acted, sym)
                        OutcomeBlock("Held back ✋", held, sym)
                        if (untagged > 0) {
                            Text(
                                "$untagged not tagged yet. Mark them Acted or Held back below to sharpen the stats.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Text(verdict(acted, held), style = MaterialTheme.typography.titleSmall)
                        if (acted.decided > 0) {
                            Text("When you acted 🥧", style = MaterialTheme.typography.titleSmall)
                            PieChart(
                                listOf(
                                    Triple("Wins", acted.wins.toFloat(), SGREEN),
                                    Triple("Losses", acted.losses.toFloat(), SRED),
                                    Triple("Flat", acted.flat.toFloat(), SGRAY)
                                )
                            )
                        }
                        Text(
                            "Based on each day's total P&L, not single trades.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            items(matches, key = { it.first.toString() }) { (d, e) ->
                JournalEntryCard(
                    date = d,
                    e = e,
                    sym = sym,
                    rev = rev,
                    onEdit = { onEdit(d) },
                    onPnl = { editDay = d },
                    extra = {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(1 to "Acted ✅", 0 to "Held back ✋", -1 to "N/A").forEach { (v, label) ->
                                val set: () -> Unit = {
                                    Store.saveJournal(ctx, d, e.copy(acted = v))
                                    rev++
                                }
                                if (e.acted == v) Button(
                                    onClick = set,
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(0.dp)
                                ) { Text(label, fontSize = 11.sp, maxLines = 1) }
                                else OutlinedButton(
                                    onClick = set,
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(0.dp)
                                ) { Text(label, fontSize = 11.sp, maxLines = 1) }
                            }
                        }
                    }
                )
            }
        }
    }
}
