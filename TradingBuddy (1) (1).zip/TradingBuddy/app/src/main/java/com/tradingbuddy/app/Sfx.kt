package com.tradingbuddy.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

// Little sound effects made from sine waves, so no audio files are needed.
// Every effect is normalised to the same loudness.
object Sfx {
    private const val RATE = 22050
    private const val TARGET_RMS = 6500.0

    private class Note(val freq: Double, val ms: Int, val decay: Double, val brass: Boolean = false)

    private fun synth(notes: List<Note>): ShortArray {
        val total = notes.sumOf { it.ms } * RATE / 1000
        val raw = DoubleArray(total)
        var pos = 0
        for (n in notes) {
            val len = n.ms * RATE / 1000
            for (i in 0 until len) {
                val t = i.toDouble() / RATE
                val attack = minOf(1.0, i / (0.006 * RATE))
                val release = minOf(1.0, (len - i) / (0.02 * RATE))
                val env = attack * release * exp(-n.decay * t)
                var s: Double
                if (n.brass) {
                    // rich, buzzy tone with vibrato: carries on small phone speakers
                    val ph = 2 * PI * n.freq * t + 0.9 * sin(2 * PI * 5.0 * t)
                    s = 0.0
                    for (h in 1..8) s += sin(h * ph) / h
                } else {
                    s = sin(2 * PI * n.freq * t) +
                        0.5 * sin(2 * PI * n.freq * 2 * t) +
                        0.25 * sin(2 * PI * n.freq * 3 * t)
                }
                if (pos + i < raw.size) raw[pos + i] = s * env
            }
            pos += len
        }
        var sum = 0.0
        for (v in raw) sum += v * v
        val rms = sqrt(sum / maxOf(1, raw.size))
        val gain = if (rms > 0) TARGET_RMS / rms else 1.0
        val out = ShortArray(raw.size)
        for (i in raw.indices) out[i] = (raw[i] * gain).coerceIn(-32000.0, 32000.0).toInt().toShort()
        return out
    }

    private fun play(c: Context, samples: ShortArray) {
        if (!Store.soundOn(c)) return
        Thread {
            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(samples.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(samples, 0, samples.size)
                track.setVolume(1.0f)
                track.play()
                Thread.sleep(samples.size * 1000L / RATE + 250)
                track.release()
            } catch (_: Exception) { }
        }.start()
    }

    // "ka-ching"
    fun coin(c: Context) = play(c, synth(listOf(Note(1319.0, 90, 14.0), Note(1976.0, 520, 5.0))))

    // sad trombone: brass tone, higher and fuller so it is not drowned out
    fun loss(c: Context) = play(
        c,
        synth(
            listOf(
                Note(440.0, 300, 0.8, true),
                Note(415.0, 300, 0.8, true),
                Note(392.0, 300, 0.8, true),
                Note(370.0, 850, 0.9, true)
            )
        )
    )

    // power-up arpeggio
    fun levelUp(c: Context) = play(
        c,
        synth(
            listOf(
                Note(523.0, 100, 8.0), Note(659.0, 100, 8.0), Note(784.0, 100, 8.0),
                Note(1047.0, 100, 8.0), Note(1319.0, 650, 4.0)
            )
        )
    )

    // calm chime
    fun chime(c: Context) = play(c, synth(listOf(Note(528.0, 800, 3.5))))
}
