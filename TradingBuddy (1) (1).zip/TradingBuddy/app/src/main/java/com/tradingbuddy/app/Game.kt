package com.tradingbuddy.app

import android.content.Context
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

data class Tier(val name: String, val emoji: String, val minXp: Int, val color: Long, val blurb: String)

// Original power-up ladder: from couch potato to legend
val TIERS = listOf(
    Tier("Couch Potato", "🥔", 0, 0xFF8D6E63, "Everyone starts here. Tick a rule, log a trade, start glowing."),
    Tier("Training Wheels", "🚲", 100, 0xFF78909C, "You showed up. Keep stacking days."),
    Tier("Rookie Fighter", "🥊", 300, 0xFF29B6F6, "Your rules are turning into habits."),
    Tier("Chart Warrior", "⚔️", 600, 0xFF26A69A, "Patient, sharp and getting dangerous."),
    Tier("Focus Monk", "🧘", 1000, 0xFF66BB6A, "Calm mind, clean entries."),
    Tier("Aura Awakened", "✨", 1600, 0xFFAB47BC, "Your discipline is literally glowing."),
    Tier("Golden Surge", "🌟", 2400, 0xFFFFC107, "Golden aura unlocked."),
    Tier("Thunder Ascendant", "⚡", 3500, 0xFFFF7043, "Lightning reflexes, iron rules."),
    Tier("Cosmic Titan", "🪐", 5000, 0xFF5C6BC0, "The markets bow to your routine."),
    Tier("Legendary Overlord", "👑", 7500, 0xFFFF1744, "Maximum power. Stay humble.")
)

data class DayPoints(val rules: Int, val plan: Int, val pnl: Int, val wellness: Int) {
    val total: Int get() = rules + plan + pnl + wellness
}

data class GameState(val xp: Int, val tier: Int, val progress: Float, val toNext: Int, val today: DayPoints)

object Game {
    private fun dateKey(k: String, prefix: String): String? {
        if (!k.startsWith(prefix)) return null
        val d = k.substring(prefix.length)
        return if (d.length == 10 && d[4] == '-' && d[7] == '-') d else null
    }

    // XP per day (max 100): rules followed 40, plan 20, P&L 30, wellness 10
    fun compute(c: Context): GameState {
        val all = Store.rawAll(c)
        val waterGoal = maxOf(1, Store.waterGoal(c))
        val stepGoal = maxOf(1, Store.stepGoal(c))
        val target = maxOf(1, Store.profitTarget(c)).toDouble()
        val scoreSum = HashMap<String, Int>()
        val scoreN = HashMap<String, Int>()
        val plans = HashMap<String, Int>()
        val pnls = HashMap<String, Double>()
        val water = HashMap<String, Int>()
        val lemon = HashMap<String, Int>()
        val steps = HashMap<String, Int>()
        val days = HashSet<String>()

        for ((k, v) in all) {
            if (k.startsWith("sc_") && k.length >= 13) {
                val d = k.substring(3, 13)
                if (d[4] == '-' && d[7] == '-') {
                    scoreSum[d] = (scoreSum[d] ?: 0) + ((v as? Int) ?: 0)
                    scoreN[d] = (scoreN[d] ?: 0) + 1
                    days.add(d)
                }
                continue
            }
            val dj = dateKey(k, "j_")
            if (dj != null) {
                try { plans[dj] = JSONObject(v as String).optInt("plan", 1) } catch (_: Exception) { }
                days.add(dj)
                continue
            }
            val dt = dateKey(k, "trades_")
            if (dt != null) {
                try {
                    val a = JSONArray(v as String)
                    var sum = 0.0
                    for (i in 0 until a.length()) sum += a.getJSONObject(i).optDouble("a", 0.0)
                    pnls[dt] = (pnls[dt] ?: 0.0) + sum
                } catch (_: Exception) { }
                days.add(dt)
                continue
            }
            val dp = dateKey(k, "pnl_")
            if (dp != null) {
                val x = (v as? String)?.toDoubleOrNull()
                if (x != null) { pnls[dp] = (pnls[dp] ?: 0.0) + x; days.add(dp) }
                continue
            }
            val dw = dateKey(k, "water_")
            if (dw != null) { water[dw] = (v as? Int) ?: 0; days.add(dw); continue }
            val dl = dateKey(k, "lemon_")
            if (dl != null) { lemon[dl] = (v as? Int) ?: 0; days.add(dl); continue }
            val ds = dateKey(k, "steps_")
            if (ds != null) { steps[ds] = (v as? Int) ?: 0; days.add(ds); continue }
        }

        fun pts(d: String): DayPoints {
            val n = scoreN[d] ?: 0
            val rules = if (n > 0) (scoreSum[d] ?: 0) / n * 40 / 100 else 0
            val plan = when (plans[d]) {
                2 -> 20
                1 -> 10
                else -> 0
            }
            val p = pnls[d]
            val pnlPts = when {
                p == null -> 0
                p > 0 -> 20 + minOf(10, (10 * p / target).toInt())
                p == 0.0 -> 5
                else -> 0
            }
            val well = (if ((water[d] ?: 0) >= waterGoal) 4 else 0) +
                (if ((steps[d] ?: 0) >= stepGoal) 4 else 0) +
                (if ((lemon[d] ?: 0) >= 1) 2 else 0)
            return DayPoints(rules, plan, pnlPts, well)
        }

        var xp = 0
        for (d in days) xp += pts(d).total
        val tier = TIERS.indexOfLast { xp >= it.minXp }.coerceAtLeast(0)
        val next = TIERS.getOrNull(tier + 1)
        val progress = if (next == null) 1f else (xp - TIERS[tier].minXp).toFloat() / (next.minXp - TIERS[tier].minXp)
        val toNext = if (next == null) 0 else next.minXp - xp
        return GameState(xp, tier, progress.coerceIn(0f, 1f), toNext, pts(LocalDate.now().toString()))
    }
}

// Glowing aura, pulsing rings and orbiting sparks; everything grows with the tier
@Composable
fun PowerAvatar(tier: Int, color: Color, emoji: String, modifier: Modifier = Modifier.size(160.dp)) {
    val inf = rememberInfiniteTransition(label = "aura")
    val pulse by inf.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            tween((950 - tier * 60).coerceAtLeast(380), easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val spin by inf.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween((4200 - tier * 300).coerceAtLeast(1200), easing = LinearEasing)),
        label = "spin"
    )
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2
            val auraR = r * (0.6f + 0.04f * tier) * pulse
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(color.copy(alpha = 0.9f), color.copy(alpha = 0f)),
                    center = c,
                    radius = auraR * 1.6f
                ),
                radius = auraR * 1.6f,
                center = c
            )
            for (i in 0..(tier / 3)) {
                drawCircle(
                    color.copy(alpha = 0.55f),
                    radius = r * (0.5f + 0.1f * i) * pulse,
                    center = c,
                    style = Stroke(width = 3f)
                )
            }
            val n = 3 + tier
            for (i in 0 until n) {
                val a = Math.toRadians(spin + i * 360.0 / n)
                val rr = r * 0.82f
                drawCircle(
                    Color.White.copy(alpha = 0.9f),
                    radius = 4f + tier / 3f,
                    center = Offset(c.x + (rr * cos(a)).toFloat(), c.y + (rr * sin(a)).toFloat())
                )
            }
        }
        Text(
            emoji,
            fontSize = 56.sp,
            modifier = Modifier.graphicsLayer {
                scaleX = pulse
                scaleY = pulse
            }
        )
    }
}

@Composable
fun HeroCard(g: GameState) {
    val tier = TIERS[g.tier]
    val color = Color(tier.color)
    val next = TIERS.getOrNull(g.tier + 1)
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.18f))
    ) {
        Column(
            Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PowerAvatar(g.tier, color, tier.emoji)
            Text(tier.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(
                "Level ${g.tier + 1} of ${TIERS.size} · Power level ${String.format(Locale.US, "%,d", g.xp * 10)}",
                style = MaterialTheme.typography.bodyMedium
            )
            if (next != null) {
                LinearProgressIndicator(
                    progress = { g.progress },
                    modifier = Modifier.fillMaxWidth(),
                    color = color
                )
                Text("${g.toNext} XP to ${next.emoji} ${next.name}", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("MAX LEVEL 🎉", fontWeight = FontWeight.Bold)
            }
            Text(tier.blurb, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
            Text(
                "Today +${g.today.total} XP · Rules ${g.today.rules}/40 · Plan ${g.today.plan}/20 · P&L ${g.today.pnl}/30 · Health ${g.today.wellness}/10",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center
            )
            Text(
                "Power comes from following your rules and your P&L together. A red day with every rule followed still levels you up.",
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center
            )
        }
    }
}
