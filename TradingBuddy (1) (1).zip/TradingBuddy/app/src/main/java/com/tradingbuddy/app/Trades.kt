package com.tradingbuddy.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val HM = DateTimeFormatter.ofPattern("HH:mm")
private val TGREEN = Color(0xFF2E9E4F)
private val TRED = Color(0xFFC62828)

fun timeStr(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalTime().format(HM)

// All trades for one day: view, add (with a time) and delete
@Composable
fun TradesDialog(date: LocalDate, sym: String, onDismiss: () -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    val list = remember(rev) { Store.trades(ctx, date) }
    val legacy = remember(rev) { Store.legacyPnl(ctx, date) }
    var sign by remember { mutableIntStateOf(1) }
    var text by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var timeText by remember {
        mutableStateOf(if (date == LocalDate.now()) LocalTime.now().format(HM) else "12:00")
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Trades · ${dateShort(date)}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val total = (legacy ?: 0.0) + list.sumOf { it.amount }
                Text("Day total ${fmtMoney(total, sym)} · ${list.size} trades", fontWeight = FontWeight.Bold)
                if (legacy != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Earlier day total: ${fmtMoney(legacy, sym)}", Modifier.weight(1f))
                        TextButton(onClick = {
                            Store.setPnl(ctx, date, null)
                            rev++
                            onChanged()
                        }) { Text("✕") }
                    }
                }
                list.forEach { t ->
                    key(t.time) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                timeStr(t.time) + "  " + fmtMoney(t.amount, sym) +
                                    (if (t.note.isNotEmpty()) "  " + t.note else ""),
                                Modifier.weight(1f),
                                color = if (t.amount >= 0) TGREEN else TRED,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            TextButton(onClick = {
                                Store.deleteTrade(ctx, date, t.time)
                                rev++
                                onChanged()
                            }) { Text("✕") }
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("Add a trade", style = MaterialTheme.typography.titleSmall)
                PnlInput(text, { text = it }, sign, { sign = it }, sym)
                OutlinedTextField(
                    value = timeText,
                    onValueChange = { timeText = it },
                    label = { Text("Time (HH:mm)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Note (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        val v = text.toDoubleOrNull()
                        if (v != null && v > 0) {
                            val lt = runCatching { LocalTime.parse(timeText.trim().padStart(5, '0')) }
                                .getOrDefault(LocalTime.NOON)
                            val ms = LocalDateTime.of(date, lt).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                            Store.addTrade(ctx, date, Trade(ms, v * sign, note.trim()))
                            text = ""
                            note = ""
                            rev++
                            onChanged()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Add trade") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

// Quick entry for use while trading
@Composable
fun TradeLoggerCard(sym: String, onLogged: (Double) -> Unit) {
    val ctx = LocalContext.current
    var sign by remember { mutableIntStateOf(1) }
    var text by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Log a trade ⚡", style = MaterialTheme.typography.titleMedium)
            PnlInput(text, { text = it }, sign, { sign = it }, sym)
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Quick note (optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val v = text.toDoubleOrNull()
                    if (v != null && v > 0) {
                        val amt = v * sign
                        Store.addTrade(ctx, LocalDate.now(), Trade(System.currentTimeMillis(), amt, note.trim()))
                        text = ""
                        note = ""
                        onLogged(amt)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Log trade") }
            Text("Timestamped automatically. Log as many as you like.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun TodayTradesCard(trades: List<Trade>, sym: String, onDelete: (Long) -> Unit) {
    val total = trades.sumOf { it.amount }
    val wins = trades.count { it.amount > 0 }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Today's trades 🧾", style = MaterialTheme.typography.titleMedium)
            if (trades.isEmpty()) {
                Text("No trades yet. Log each one as you take it.", style = MaterialTheme.typography.bodySmall)
            } else {
                Text(
                    fmtMoney(total, sym),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (total > 0) TGREEN else if (total < 0) TRED else Color.Unspecified
                )
                Text(
                    "${trades.size} trades · $wins wins · ${trades.size - wins} losses · win rate ${wins * 100 / trades.size}%",
                    style = MaterialTheme.typography.bodySmall
                )
                trades.reversed().forEach { t ->
                    key(t.time) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(timeStr(t.time), Modifier.width(52.dp), style = MaterialTheme.typography.bodySmall)
                            Text(
                                fmtMoney(t.amount, sym),
                                Modifier.width(110.dp),
                                color = if (t.amount >= 0) TGREEN else TRED,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                t.note,
                                Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall
                            )
                            TextButton(onClick = { onDelete(t.time) }) { Text("✕") }
                        }
                    }
                }
            }
        }
    }
}
