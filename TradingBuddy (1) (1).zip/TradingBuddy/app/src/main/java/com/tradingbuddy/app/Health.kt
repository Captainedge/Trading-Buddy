package com.tradingbuddy.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale

private const val LB = 2.20462

private fun stepPermOk(c: Context): Boolean =
    Build.VERSION.SDK_INT < 29 ||
        ContextCompat.checkSelfPermission(c, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED

// ---------------- Health tab: water, lemon, steps, weight ----------------
@Composable
fun HealthTab(tick: Int, fx: (List<String>) -> Unit) {
    val ctx = LocalContext.current
    val today = LocalDate.now()
    var rev by remember { mutableIntStateOf(0) }
    val water = remember(rev, tick) { Store.water(ctx, today) }
    val goal = maxOf(1, remember(tick) { Store.waterGoal(ctx) })
    val lemon = remember(rev, tick) { Store.lemon(ctx, today) }
    val steps = remember(rev, tick) { Store.stepsOn(ctx, today) }
    val stepGoal = maxOf(1, remember(tick) { Store.stepGoal(ctx) })
    val unit = remember(rev, tick) { Store.str(ctx, "wunit", "kg") }
    var hasPerm by remember { mutableStateOf(stepPermOk(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPerm = it }
    val sensorOk = remember {
        (ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager).getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null
    }
    var wText by remember { mutableStateOf("") }
    val history = remember(rev, tick) { Store.weightHistory(ctx, 90) }

    // live step counting while this tab is open
    DisposableEffect(hasPerm) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                Store.onStepReading(ctx, e.values[0].toLong())
                rev++
            }
            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) { }
        }
        if (hasPerm && sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }

    TabList {
        item {
            Text("Health ❤️", style = MaterialTheme.typography.headlineMedium)
            Text("A sharp body makes a sharp trader. Healthy habits add XP to your hero too.")
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("💧 Hydration", style = MaterialTheme.typography.titleMedium)
                    Text("$water of $goal glasses today")
                    LinearProgressIndicator(
                        progress = { (water.toFloat() / goal).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            Store.addWater(ctx, today, 1)
                            rev++
                            if (water + 1 == goal) {
                                Sfx.chime(ctx)
                                fx(listOf("💧", "💦", "🎉"))
                            } else {
                                fx(listOf("💧"))
                            }
                        }) { Text("+1 glass 💧") }
                        OutlinedButton(onClick = { Store.addWater(ctx, today, -1); rev++ }) { Text("−1") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🍋 Lemon juice", style = MaterialTheme.typography.titleMedium)
                    Text("$lemon today")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            Store.addLemon(ctx, today, 1)
                            rev++
                            fx(listOf("🍋"))
                        }) { Text("+1 lemon 🍋") }
                        OutlinedButton(onClick = { Store.addLemon(ctx, today, -1); rev++ }) { Text("−1") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("👟 Steps", style = MaterialTheme.typography.titleMedium)
                    if (!sensorOk) {
                        Text("This phone has no step sensor.")
                    } else if (!hasPerm) {
                        Text("Allow activity recognition so Trading Buddy can count your steps.")
                        Button(onClick = { permLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION) }) {
                            Text("Enable step counter")
                        }
                    } else {
                        Text(
                            "${String.format(Locale.US, "%,d", steps)} of ${String.format(Locale.US, "%,d", stepGoal)} steps",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        LinearProgressIndicator(
                            progress = { (steps.toFloat() / stepGoal).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "Counts in the background while the timer is running, and whenever you open this tab.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("⚖️ Weight", style = MaterialTheme.typography.titleMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = wText,
                            onValueChange = { v -> wText = v.filter { it.isDigit() || it == '.' } },
                            label = { Text("Today's weight ($unit)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = {
                            val v = wText.toDoubleOrNull()
                            if (v != null && v > 0) {
                                Store.setWeightKg(ctx, today, if (unit == "lb") v / LB else v)
                                wText = ""
                                rev++
                            }
                        }) { Text("Log") }
                    }
                    if (history.isEmpty()) {
                        Text("No weigh-ins yet.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        val show = { kg: Double -> String.format(Locale.US, "%.1f", if (unit == "lb") kg * LB else kg) }
                        val latest = history.last().second
                        val first = history.first().second
                        val diff = latest - first
                        Text(
                            "Latest ${show(latest)} $unit" +
                                (if (history.size > 1) " · change ${if (diff >= 0) "+" else "-"}${show(kotlin.math.abs(diff))} $unit since ${history.first().first}" else ""),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        WeightChart(history, if (unit == "lb") LB else 1.0)
                        history.takeLast(5).reversed().forEach { (d, kg) ->
                            key(d) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("${dateShort(d)}  ${show(kg)} $unit", Modifier.weight(1f))
                                    TextButton(onClick = { Store.setWeightKg(ctx, d, null); rev++ }) { Text("✕") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeightChart(points: List<Pair<LocalDate, Double>>, factor: Double) {
    val line = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outline
    if (points.size < 2) return
    val vals = points.map { it.second * factor }
    val minV = vals.min()
    val maxV = vals.max()
    val range = maxOf(0.5, maxV - minV)
    val startDay = points.first().first
    val span = maxOf(1L, ChronoUnit.DAYS.between(startDay, points.last().first))
    Canvas(Modifier.fillMaxWidth().height(120.dp)) {
        drawLine(grid, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = 2f)
        var prev: Offset? = null
        points.forEachIndexed { i, (d, _) ->
            val x = size.width * ChronoUnit.DAYS.between(startDay, d).toFloat() / span
            val y = size.height * (0.9f - 0.8f * ((vals[i] - minV) / range).toFloat())
            val p = Offset(x, y)
            prev?.let { drawLine(line, it, p, strokeWidth = 5f) }
            drawCircle(line, radius = 7f, center = p)
            prev = p
        }
    }
}

// ---------------- Settings card for health, breaks and fun ----------------
@Composable
private fun SettingStepper(label: String, key: String, def: Int, step: Int, max: Int, text: (Int) -> String) {
    val ctx = LocalContext.current
    var v by remember { mutableIntStateOf(Store.int(ctx, key, def)) }
    Stepper(label, v, step, max, text) {
        v = it
        Store.putInt(ctx, key, it)
    }
}

@Composable
fun WellnessSettings() {
    val ctx = LocalContext.current
    val sym = remember { Store.currency(ctx) }
    var sound by remember { mutableStateOf(Store.soundOn(ctx)) }
    var unit by remember { mutableStateOf(Store.str(ctx, "wunit", "kg")) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Health & reminders 💧", style = MaterialTheme.typography.titleMedium)
            SettingStepper("Water reminder every", "water_every", 60, 15, 180) { if (it == 0) "Off" else "$it m" }
            SettingStepper("Water goal (glasses)", "water_goal", 8, 1, 20) { "$it" }
            SettingStepper("Lemon juice reminder", "lemon_hour", 10, 1, 20) { if (it == 0) "Off" else "$it:00" }
            SettingStepper("Step goal", "step_goal", 8000, 1000, 30000) { String.format(Locale.US, "%,d", it) }
            Text("Breaks 🌬️", style = MaterialTheme.typography.titleMedium)
            SettingStepper("Breathe & walk after", "break_after", 60, 15, 240) { if (it == 0) "Off" else "$it m" }
            SettingStepper("Waiting for a setup", "wait_after", 30, 5, 180) { if (it == 0) "Off" else "$it m" }
            Text(
                "Reminders appear while the timer is running. The break popup includes a guided breathing circle.",
                style = MaterialTheme.typography.bodySmall
            )
            Text("Game 🎮", style = MaterialTheme.typography.titleMedium)
            SettingStepper("Daily profit target", "profit_target", 100, 50, 5000) { "$sym$it" }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Sound effects 🔊", Modifier.weight(1f))
                Switch(checked = sound, onCheckedChange = { sound = it; Store.putBool(ctx, "sound", it) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { Sfx.coin(ctx) }) { Text("Coin 💰") }
                TextButton(onClick = { Sfx.loss(ctx) }) { Text("Loss 💸") }
                TextButton(onClick = { Sfx.levelUp(ctx) }) { Text("Level up ⚡") }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Weight unit", Modifier.weight(1f))
                listOf("kg", "lb").forEach { u ->
                    if (unit == u) Button(onClick = { unit = u; Store.putStr(ctx, "wunit", u) }) { Text(u) }
                    else OutlinedButton(onClick = { unit = u; Store.putStr(ctx, "wunit", u) }) { Text(u) }
                }
            }
        }
    }
}
